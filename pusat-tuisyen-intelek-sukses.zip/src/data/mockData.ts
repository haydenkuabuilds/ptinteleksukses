import { SubjectItem, ProgramItem, TutorProfile, FAQItem } from '../types';
import logoPhoto from '../assets/images/regenerated_image_1788005864607.png';
import tutorStudentPhoto from '../assets/images/tutor_student_photo_1787998690779.jpg';
import classroomPhotoReal from '../assets/images/classroom_real_photo_1787998676844.jpg';
import cikguRalliyaPhoto from '../assets/images/regenerated_image_1788004330628.png';

export const ASSETS = {
  logo: logoPhoto, // screen.png - Pusat Tuisyen Intelek Sukses colorful head & arrows logo
  classroomPhoto: classroomPhotoReal, // WhatsApp Image 2026-08-29 at 5.57.06 PM.jpeg - Real classroom with yellow tables & curtains
  tutorSuccessPhoto: tutorStudentPhoto, // WhatsApp Image 2026-08-29 at 4.48.31 PM.jpeg - Teacher & student receiving certificate
  cikguRalliya: cikguRalliyaPhoto, // screen1.png - Cikgu Ralliya portrait with name tag
};

export const CONTACT_INFO = {
  centerName: 'Pusat Tuisyen Intelek Sukses',
  tagline: 'Empowering Young Minds, Achieving Academic Excellence.',
  taglineBm: 'Memperkasa Minda Muda, Mencapai Kecemerlangan Akademik',
  address: '23A, Jalan Bayu Tinggi 1A, Batu Unjur, 41200 Klang, Selangor Darul Ehsan.',
  phone: '03-3323 1234 / 012-345 6789',
  primaryPhone: '03-3323 1234',
  mobilePhone: '012-345 6789',
  whatsapp: '012-345 6789',
  email: 'inteleksukses@gmail.com',
  secondaryEmail: 'info@pusattuisyeninteleksukses.com',
  hoursWeekday: 'Isnin - Jumaat: 2.00 petang - 10.00 malam',
  hoursWeekend: 'Sabtu - Ahad: 9.00 pagi - 6.00 petang',
  locationCoordinates: 'Klang, Selangor Darul Ehsan',
  googleMapsUrl: 'https://maps.google.com/?q=23A+Jalan+Bayu+Tinggi+1A+Batu+Unjur+41200+Klang+Selangor',
  wazeUrl: 'https://waze.com/ul?q=23A+Jalan+Bayu+Tinggi+1A+Batu+Unjur+Klang',
  packageDisclaimer: 'Sila ambil perhatian: Maklumat pakej dan tawaran promosi mungkin telah berubah atau tamat tempoh kerana laman web tidak sentiasa dikemas kini secara berkala. Sila hubungi kami secara langsung melalui WhatsApp atau telefon untuk mengesahkan pakej, jadual, dan tawaran terkini.'
};

export const SUBJECTS: SubjectItem[] = [
  {
    id: 'bm',
    name: 'Bahasa Malaysia',
    category: 'Bahasa',
    iconType: 'globe',
    accentColor: '#1A3668',
    description: 'Penguasaan tatabahasa, kosa kata dinamik, pemahaman teks, dan teknik penulisan karangan bermutu tinggi dibimbing oleh pakar Bahasa Melayu.',
    levels: ['Prasekolah', 'Tahun 1-6 (KSSR)', 'Tingkatan 1-3 (UASA)', 'Tingkatan 4-5 (SPM)'],
    features: ['Teknik membina ayat gramatis', 'Skor A Karangan Berformat', 'Modul kosa kata berimpak tinggi'],
    scheduleDay: 'Isnin & Rabu',
    scheduleTime: '4:00 PM - 5:30 PM / 8:00 PM - 9:30 PM',
    tutorName: 'Cikgu Ralliya'
  },
  {
    id: 'bi',
    name: 'English (National & Cambridge)',
    category: 'Bahasa',
    iconType: 'user-voice',
    accentColor: '#1A3668',
    description: 'Standard National Syllabus & Cambridge Syllabus focusing on grammar precision, active listening, comprehension, and essay excellence.',
    levels: ['Preschool', 'Primary 1-6 (CEFR)', 'Form 1-3 (UASA)', 'Form 4-5 (SPM 1119)'],
    features: ['Standard National & Cambridge Syllabus', 'Structured CEFR grammar mastery', 'Guided writing & essay templates'],
    scheduleDay: 'Selasa & Khamis',
    scheduleTime: '4:00 PM - 5:30 PM / 8:00 PM - 9:30 PM',
    tutorName: 'Guru Berpengalaman'
  },
  {
    id: 'mandarin',
    name: 'Mandarin',
    category: 'Bahasa',
    iconType: 'translate',
    accentColor: '#1A3668',
    description: 'Pengukuhan Hanyu Pinyin, struktur aksara Hanzi, kefahaman petikan, dan penulisan karangan Bahasa Cina SK & SJKC.',
    levels: ['SJKC Tahun 1-6', 'SK Bahasa Komunikasi', 'Menengah Rendah & SPM'],
    features: ['Penguasaan sistem Pinyin pantas', 'Hafalan karakter visual', 'Latihan bina ayat dan karangan'],
    scheduleDay: 'Jumaat',
    scheduleTime: '4:30 PM - 6:30 PM',
    tutorName: 'Guru Berpengalaman'
  },
  {
    id: 'tamil',
    name: 'Tamil',
    category: 'Bahasa',
    iconType: 'az',
    accentColor: '#1A3668',
    description: 'Bimbingan tatabahasa (Ilakkanam), kefahaman kosa kata, sastera asas, dan karangan Bahasa Tamil untuk SJKT & Menengah.',
    levels: ['SJKT Tahun 1-6', 'Tingkatan 1-3', 'SPM Bahasa Tamil'],
    features: ['Tatabahasa & Ilakkanam mantap', 'Teknik kupasan sastera', 'Bimbingan penulisan kreatif'],
    scheduleDay: 'Sabtu',
    scheduleTime: '10:00 AM - 12:00 PM',
    tutorName: 'Guru Berpengalaman'
  },
  {
    id: 'math',
    name: 'Mathematics',
    category: 'STEM',
    iconType: 'math',
    accentColor: '#28A745',
    description: 'Membina asas nombor yang kukuh, logik penyelesaian masalah KBAT, dan formula ringkas untuk skor cemerlang.',
    levels: ['Prasekolah', 'Tahun 1-6 (DLP / BM)', 'Tingkatan 1-3', 'Tingkatan 4-5 (SPM)'],
    features: ['Teknik Menjawab KBAT Pantas', 'Latih tubi topikal berperingkat', 'Pemulihan kelemahan asas matematik'],
    scheduleDay: 'Isnin & Jumaat',
    scheduleTime: '5:30 PM - 7:00 PM / 8:00 PM - 9:30 PM',
    tutorName: 'Guru Berpengalaman'
  },
  {
    id: 'addmath',
    name: 'Additional Mathematics',
    category: 'STEM',
    iconType: 'sigma',
    accentColor: '#28A745',
    description: 'Matematik Tambahan peringkat SPM. Menghuraikan konsep kalkulus, algebra lanjutan, trigonometri, dan statistik secara visual.',
    levels: ['Tingkatan 4 SPM', 'Tingkatan 5 SPM'],
    features: ['Formula breakdown langkah-demi-langkah', 'Koleksi soalan Percubaan Negeri & SBP', 'Teknik skor Kertas 1 & Kertas 2'],
    scheduleDay: 'Rabu & Sabtu',
    scheduleTime: '8:00 PM - 10:00 PM (Rabu) / 2:00 PM - 4:00 PM (Sabtu)',
    tutorName: 'Guru Berpengalaman'
  },
  {
    id: 'science',
    name: 'Science',
    category: 'STEM',
    iconType: 'science',
    accentColor: '#FFC107',
    description: 'Eksplorasi konsep sains praktikal, format soalan eksperimen KSSR/KSSM, dan kaedah menjawab istilah saintifik dengan tepat.',
    levels: ['Sains Tahun 1-6 (DLP / BM)', 'Sains Teras Menengah', 'Fizik / Kimia / Biologi SPM'],
    features: ['Penerangan konsep interaktif', 'Teknik menjawab soalan pembolehubah', 'Peta minda ringkas padat'],
    scheduleDay: 'Selasa & Sabtu',
    scheduleTime: '5:30 PM - 7:00 PM / 9:00 AM - 11:00 AM',
    tutorName: 'Guru Berpengalaman'
  },
  {
    id: 'phonics',
    name: 'Phonics Foundation',
    category: 'Bahasa',
    iconType: 'phonics',
    accentColor: '#6F42C1',
    description: 'Program asas fonik berstruktur (Jolly Phonics & Fonetik BM) untuk kanak-kanak prasekolah dan murid tahap 1.',
    levels: ['Prasekolah (4-6 Tahun)', 'Tahun 1 & 2 Pemulihan'],
    features: ['Pengenalan 42 bunyi huruf', 'Teknik blending & segmenting lancar', 'Bahan bacaan bergambar ceria'],
    scheduleDay: 'Sabtu & Ahad',
    scheduleTime: '9:00 AM - 10:30 AM / 11:00 AM - 12:30 PM',
    tutorName: 'Guru Berpengalaman'
  },
  {
    id: 'speedmath',
    name: 'Fast Calculation Techniques (Teknik Kiraan Cepat)',
    category: 'Pengkhususan',
    iconType: 'speed-math',
    accentColor: '#28A745',
    description: 'Kaedah aritmetik mental & jalan kira sepintas lalu untuk meningkatkan kelajuan dan ketepatan pengiraan tanpa kalkulator.',
    levels: ['Prasekolah', 'Semua Murid Rendah & Menengah'],
    features: ['Formula semakan silang pantas', 'Latihan ketangkasan otak kiri & kanan', 'Meningkatkan keyakinan ujian masa terhad'],
    scheduleDay: 'Ahad',
    scheduleTime: '2:00 PM - 3:30 PM',
    tutorName: 'Guru Berpengalaman'
  },
];

export const PROGRAMS: ProgramItem[] = [
  {
    id: 'after-school',
    title: 'After-School Programs (Program Selepas Sekolah)',
    badge: 'Program Utama',
    description: 'Supervised learning environments, homework guidance, and structured academic support outside regular school hours. Persekitaran pembelajaran berstruktur dengan bimbingan tutor pakar untuk membantu menyiapkan kerja sekolah dan ulang kaji berkesan.',
    bulletPoints: [
      'Supervised learning environment & homework guidance',
      'Structured academic support outside regular school hours',
      'Latih tubi topikal harian sejajar silibus KSSR/KSSM',
      'Suasana bilik darjah selesa berhawa dingin dan kondusif'
    ],
    targetAudience: 'Prasekolah, Sekolah Rendah & Menengah (Tahun 1 hingga Tingkatan 5)',
    feeInfo: 'Pakej yuran berpatutan (Hubungi kami untuk tawaran terkini)'
  },
  {
    id: 'free-reading',
    title: 'Free Reading & Writing Packages (Pakej Membaca & Menulis Percuma)',
    badge: 'Modul Literasi Asas',
    description: 'Special early literacy modules designed to boost confidence in foundational language skills. Penguasaan suku kata, pembinaan ayat mudah, dan teknik menulis dengan kemas.',
    bulletPoints: [
      'Special early literacy modules for foundational language skills',
      'Penguasaan suku kata terbuka dan tertutup',
      'Meningkatkan keyakinan dan kemahiran membaca & menulis',
      'Bimbingan mesra pelajar oleh guru berdedikasi'
    ],
    targetAudience: 'Prasekolah & Murid Tahap 1 (Tahun 1 & 2)',
    feeInfo: 'Tertakluk kepada syarat pendaftaran & ketersediaan semasa'
  },
  {
    id: 'free-trial',
    title: 'Free Trial Classes (Kelas Percubaan Percuma)',
    badge: 'Tanpa Komitmen',
    description: 'No-obligation introductory trial sessions for eligible new students to experience our teaching style and structured learning modules.',
    bulletPoints: [
      'No-obligation introductory trial sessions',
      'Mengalami sendiri kaedah & kualiti pengajaran guru',
      'Ujian diagnostik tahap penguasaan murid',
      'Konsultasi pendidikan bersama tenaga pengajar'
    ],
    targetAudience: 'Terbuka kepada semua murid baharu yang layak',
    feeInfo: 'Sesi pengenalan percuma (Tertakluk kepada ketersediaan jadual)'
  }
];

export const TUTORS: TutorProfile[] = [
  {
    id: 'tutor-1',
    name: 'Cikgu Ralliya (Ralliya Sahol Hamid / Cikgu Liya)',
    role: 'Principal Bahasa Melayu Specialist & Program Director',
    experience: 'Pendidik Berpengalaman Luas',
    specialization: [
      'Principal Bahasa Melayu Specialist',
      'Core Academic Development',
      'Primary Language Mastery',
      'Targeted Exam Workshop Seminars'
    ],
    education: 'Lead Educator & Program Director Pusat Tuisyen Intelek Sukses (Klang)',
    bio: 'Cikgu Ralliya (juga dikenali sebagai Cikgu Liya) merupakan Principal Bahasa Melayu Specialist, ketua tenaga pengajar, dan pengarah program bagi Pusat Tuisyen Intelek Sukses di Klang. Beliau memfokuskan kepada pembangunan akademik teras, penguasaan bahasa peringkat rendah, dan bengkel teknik peperiksaan berfokus.'
  }
];

export const FAQS: FAQItem[] = [
  {
    category: 'Pendaftaran & Yuran',
    question: 'Bagaimanakah cara untuk mendaftar kelas percubaan percuma (Free Trial Classes)?',
    answer: 'Anda boleh menghubungi kami secara terus melalui WhatsApp atau telefon di 012-345 6789 / 03-3323 1234, dan kami akan membantu mengatur sesi pengenalan yang bersesuaian.'
  },
  {
    category: 'Pendaftaran & Yuran',
    question: 'Adakah pakej dan promosi di laman web sentiasa sah?',
    answer: 'Sila ambil perhatian bahawa pakej dan tawaran promosi mungkin tertakluk kepada perubahan atau telah tamat kerana laman web tidak sentiasa dikemas kini secara berkala. Sila hubungi pihak kami melalui WhatsApp untuk maklumat pakej terkini.'
  },
  {
    category: 'Program & Silibus',
    question: 'Apakah subjek dan kurikulum yang ditawarkan?',
    answer: 'Kami menawarkan Bahasa Malaysia, English (Standard National & Cambridge Syllabus), Mandarin, Tamil, Mathematics, Additional Mathematics, Science, Phonics Foundation, serta Fast Calculation Techniques (Teknik Kiraan Cepat).'
  },
  {
    category: 'Fasiliti & Lokasi',
    question: 'Di manakah lokasi Pusat Tuisyen Intelek Sukses?',
    answer: 'Pusat tuisyen kami terletak di 23A, Jalan Bayu Tinggi 1A, Batu Unjur, 41200 Klang, Selangor Darul Ehsan.'
  },
  {
    category: 'Program & Silibus',
    question: 'Siapakah golongan sasaran (target audience) Pusat Tuisyen Intelek Sukses?',
    answer: 'Program kami terbuka kepada murid Prasekolah (Preschool), Sekolah Rendah (Primary), dan Sekolah Menengah (Secondary school students).'
  }
];
