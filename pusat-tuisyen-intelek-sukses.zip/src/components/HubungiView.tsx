import React, { useState } from 'react';
import { CONTACT_INFO, ASSETS } from '../data/mockData';
import { ContactFormData } from '../types';
import { 
  MapPin, 
  Phone, 
  Mail, 
  Clock, 
  Send, 
  CheckCircle2, 
  ExternalLink, 
  Navigation,
  MessageSquare
} from 'lucide-react';

interface HubungiViewProps {
  onSuccessToast: (msg: string) => void;
}

export const HubungiView: React.FC<HubungiViewProps> = ({ onSuccessToast }) => {
  const [formData, setFormData] = useState<ContactFormData>({
    fullName: '',
    phone: '',
    email: '',
    subject: 'Pertanyaan Umum',
    message: '',
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.fullName.trim() || !formData.phone.trim()) {
      alert('Sila lengkapkan nama penuh dan nombor telefon.');
      return;
    }

    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      setSubmitted(true);
      onSuccessToast('Mesej anda telah berjaya dihantar! Pihak pengurusan Intelek Sukses akan menghubungi anda segera.');
    }, 800);
  };

  const handleReset = () => {
    setFormData({
      fullName: '',
      phone: '',
      email: '',
      subject: 'Pertanyaan Umum',
      message: '',
    });
    setSubmitted(false);
  };

  return (
    <div className="py-8 md:py-14 max-w-[1280px] mx-auto px-4 md:px-6">
      
      {/* Header Section */}
      <div className="text-center mb-12 max-w-3xl mx-auto space-y-3">
        <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-[#00204f] tracking-tight">
          Hubungi Kami
        </h1>
        <p className="text-base sm:text-lg text-[#44474f] leading-relaxed">
          Kami sedia membantu anda. Sila hubungi kami untuk sebarang pertanyaan atau untuk mendaftar anak anda.
        </p>
      </div>

      {/* Two Column Layout for Contact Info & Form */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-10 items-start">
        
        {/* Left Column: Contact Details Card & Map */}
        <div className="flex flex-col gap-6">
          
          {/* Contact Details Card */}
          <div className="bg-white rounded-xl p-6 sm:p-8 shadow-[0_4px_16px_rgba(0,32,79,0.06)] border border-[#e0e3e5]">
            <h2 className="text-xl font-bold text-[#00204f] mb-6 border-b-2 border-[#00204f] w-fit pb-1.5">
              Maklumat Perhubungan
            </h2>

            <ul className="flex flex-col gap-5 text-sm sm:text-base text-[#191c1e]">
              {/* Address */}
              <li className="flex items-start gap-3.5">
                <span className="material-symbols-outlined fill text-[#F37021] text-2xl shrink-0 mt-0.5">location_on</span>
                <div>
                  <strong className="block text-[#00204f] font-bold">Alamat:</strong>
                  <span className="text-[#44474f] leading-snug">
                    {CONTACT_INFO.address}
                  </span>
                </div>
              </li>

              {/* Phone */}
              <li className="flex items-start gap-3.5">
                <span className="material-symbols-outlined fill text-[#F37021] text-2xl shrink-0 mt-0.5">call</span>
                <div>
                  <strong className="block text-[#00204f] font-bold">Telefon:</strong>
                  <a href={`tel:${CONTACT_INFO.phone}`} className="text-[#44474f] hover:text-[#00204f] font-medium transition-colors">
                    {CONTACT_INFO.phone}
                  </a>
                </div>
              </li>

              {/* Email */}
              <li className="flex items-start gap-3.5">
                <span className="material-symbols-outlined fill text-[#F37021] text-2xl shrink-0 mt-0.5">mail</span>
                <div>
                  <strong className="block text-[#00204f] font-bold">E-mel:</strong>
                  <a href={`mailto:${CONTACT_INFO.email}`} className="text-[#44474f] hover:text-[#00204f] font-medium transition-colors">
                    {CONTACT_INFO.email}
                  </a>
                </div>
              </li>

              {/* Operating Hours */}
              <li className="flex items-start gap-3.5">
                <span className="material-symbols-outlined fill text-[#F37021] text-2xl shrink-0 mt-0.5">schedule</span>
                <div>
                  <strong className="block text-[#00204f] font-bold">Waktu Operasi:</strong>
                  <span className="text-[#44474f] leading-relaxed block">
                    {CONTACT_INFO.hoursWeekday}<br />
                    {CONTACT_INFO.hoursWeekend}
                  </span>
                </div>
              </li>
            </ul>

            {/* Quick Action Buttons */}
            <div className="mt-6 pt-5 border-t border-[#f2f4f6] flex flex-wrap gap-2.5">
              <a
                href={`https://wa.me/60123456789?text=Salam%20Pusat%20Tuisyen%20Intelek%20Sukses,%20saya%20ingin%20mendapatkan%20maklumat%20lokasi%20dan%20pendaftaran.`}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#28A745]/10 text-[#28A745] hover:bg-[#28A745]/20 font-bold text-xs transition-colors"
              >
                <MessageSquare className="w-4 h-4" />
                <span>WhatsApp Pengurusan</span>
              </a>
              <a
                href={CONTACT_INFO.googleMapsUrl}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#f2f4f6] text-[#00204f] hover:bg-[#e0e3e5] font-bold text-xs transition-colors"
              >
                <Navigation className="w-3.5 h-3.5" />
                <span>Petunjuk Arah Google Maps</span>
              </a>
            </div>
          </div>

          {/* Location & Navigation Card */}
          <div className="w-full bg-[#f8fafe] rounded-xl overflow-hidden border border-[#c4c6d0] shadow-sm relative group p-6 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-lg bg-[#d8e2ff] flex items-center justify-center text-[#00204f]">
                  <MapPin className="w-5 h-5 text-[#F37021]" />
                </div>
                <div>
                  <h4 className="font-bold text-sm text-[#00204f]">Lokasi Pusat Tuisyen</h4>
                  <p className="text-xs text-[#747780]">Bayu Tinggi, Klang, Selangor</p>
                </div>
              </div>
              <div className="flex gap-2">
                <a
                  href={CONTACT_INFO.googleMapsUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="bg-[#00204f] hover:bg-[#1a3668] text-white text-xs font-bold px-3 py-1.5 rounded-lg shadow-sm flex items-center gap-1.5 transition-all"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>Google Maps</span>
                </a>
                <a
                  href={CONTACT_INFO.wazeUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="bg-[#F37021] hover:bg-[#d95e14] text-white text-xs font-bold px-3 py-1.5 rounded-lg shadow-sm flex items-center gap-1.5 transition-all"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>Waze</span>
                </a>
              </div>
            </div>

            <div className="rounded-xl overflow-hidden border border-[#e0e3e5] bg-white aspect-[16/9] relative">
              <img
                src={ASSETS.classroomPhoto}
                alt="Pusat Tuisyen Intelek Sukses Klang"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#00204f]/80 via-transparent to-transparent flex items-end p-4">
                <p className="text-white text-xs font-medium">
                  {CONTACT_INFO.address}
                </p>
              </div>
            </div>
          </div>

        </div>

        {/* Right Column: Contact Form */}
        <div className="bg-white rounded-xl p-6 sm:p-8 shadow-[0_4px_16px_rgba(0,32,79,0.06)] border-t-4 border-t-[#F37021] border border-[#e0e3e5]">
          <h2 className="text-xl sm:text-2xl font-bold text-[#00204f] mb-6">
            Hantar Mesej
          </h2>

          {submitted ? (
            <div className="py-8 text-center space-y-4 animate-in fade-in duration-300">
              <div className="w-16 h-16 rounded-full bg-[#d4edda] text-[#28A745] flex items-center justify-center mx-auto shadow-sm">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold text-[#00204f]">Terima Kasih!</h3>
              <p className="text-[#44474f] text-sm max-w-md mx-auto leading-relaxed">
                Mesej anda telah berjaya diterima oleh pihak Pusat Tuisyen Intelek Sukses. Pegawai pendidikan kami akan menghubungi anda melalui telefon/WhatsApp dalam tempoh 24 jam.
              </p>
              <div className="pt-4 flex justify-center gap-3">
                <button
                  onClick={handleReset}
                  className="px-5 py-2.5 rounded-lg border border-[#c4c6d0] text-xs font-bold text-[#00204f] hover:bg-[#f2f4f6]"
                >
                  Hantar Mesej Baharu
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="flex flex-col gap-4">
              {/* Nama Penuh */}
              <div>
                <label className="block text-xs sm:text-sm font-bold text-[#00204f] mb-1.5" htmlFor="fullName">
                  Nama Penuh <span className="text-[#ba1a1a]">*</span>
                </label>
                <input
                  type="text"
                  id="fullName"
                  name="fullName"
                  required
                  value={formData.fullName}
                  onChange={handleChange}
                  placeholder="Masukkan nama penuh anda"
                  className="w-full rounded-lg bg-white border border-[#c4c6d0] px-4 py-2.5 text-sm sm:text-base text-[#191c1e] placeholder:text-[#747780]/60 focus:outline-none focus:border-[#00204f] focus:ring-2 focus:ring-[#00204f]/15 transition-all"
                />
              </div>

              {/* Phone & Email Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs sm:text-sm font-bold text-[#00204f] mb-1.5" htmlFor="phone">
                    Nombor Telefon <span className="text-[#ba1a1a]">*</span>
                  </label>
                  <input
                    type="tel"
                    id="phone"
                    name="phone"
                    required
                    value={formData.phone}
                    onChange={handleChange}
                    placeholder="012-345 6789"
                    className="w-full rounded-lg bg-white border border-[#c4c6d0] px-4 py-2.5 text-sm sm:text-base text-[#191c1e] placeholder:text-[#747780]/60 focus:outline-none focus:border-[#00204f] focus:ring-2 focus:ring-[#00204f]/15 transition-all"
                  />
                </div>

                <div>
                  <label className="block text-xs sm:text-sm font-bold text-[#00204f] mb-1.5" htmlFor="email">
                    Alamat E-mel
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="emel@contoh.com"
                    className="w-full rounded-lg bg-white border border-[#c4c6d0] px-4 py-2.5 text-sm sm:text-base text-[#191c1e] placeholder:text-[#747780]/60 focus:outline-none focus:border-[#00204f] focus:ring-2 focus:ring-[#00204f]/15 transition-all"
                  />
                </div>
              </div>

              {/* Perkara Dropdown */}
              <div>
                <label className="block text-xs sm:text-sm font-bold text-[#00204f] mb-1.5" htmlFor="subject">
                  Perkara
                </label>
                <select
                  id="subject"
                  name="subject"
                  value={formData.subject}
                  onChange={handleChange}
                  className="w-full rounded-lg bg-white border border-[#c4c6d0] px-4 py-2.5 text-sm sm:text-base text-[#191c1e] focus:outline-none focus:border-[#00204f] focus:ring-2 focus:ring-[#00204f]/15 transition-all"
                >
                  <option value="Pertanyaan Umum">Pertanyaan Umum</option>
                  <option value="Pendaftaran Pelajar">Pendaftaran Pelajar</option>
                  <option value="Kelas Percubaan Percuma">Kelas Percubaan Percuma</option>
                  <option value="Pakej Membaca & Menulis">Pakej Membaca & Menulis Percuma</option>
                  <option value="Maklumat Yuran & Jadual">Maklumat Yuran & Jadual Kelas</option>
                  <option value="Lain-lain">Lain-lain</option>
                </select>
              </div>

              {/* Mesej Anda */}
              <div>
                <label className="block text-xs sm:text-sm font-bold text-[#00204f] mb-1.5" htmlFor="message">
                  Mesej Anda <span className="text-[#ba1a1a]">*</span>
                </label>
                <textarea
                  id="message"
                  name="message"
                  required
                  rows={4}
                  value={formData.message}
                  onChange={handleChange}
                  placeholder="Taip mesej anda di sini..."
                  className="w-full rounded-lg bg-white border border-[#c4c6d0] px-4 py-2.5 text-sm sm:text-base text-[#191c1e] placeholder:text-[#747780]/60 focus:outline-none focus:border-[#00204f] focus:ring-2 focus:ring-[#00204f]/15 transition-all resize-none"
                />
              </div>

              {/* Submit Button */}
              <div className="pt-2">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="bg-[#F37021] hover:bg-[#d95e14] text-white font-bold text-sm sm:text-base px-8 py-3.5 rounded-lg hover:-translate-y-0.5 active:translate-y-0 transition-all shadow-[0_4px_12px_rgba(243,112,33,0.2)] flex items-center justify-center gap-2 w-full sm:w-auto"
                >
                  {isSubmitting ? (
                    <span>Menghantar...</span>
                  ) : (
                    <>
                      <span>Hantar Mesej</span>
                      <Send className="w-4 h-4" />
                    </>
                  )}
                </button>
              </div>
            </form>
          )}

        </div>

      </div>
    </div>
  );
};
