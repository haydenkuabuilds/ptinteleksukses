import React from 'react';
import { PageTab } from '../types';
import { CONTACT_INFO } from '../data/mockData';
import { MapPin, Phone, Mail, Clock, ArrowRight } from 'lucide-react';

interface FooterProps {
  onSelectTab: (tab: PageTab) => void;
  onOpenFAQ?: () => void;
  onOpenPrivacy?: () => void;
  onOpenTerms?: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  onSelectTab,
  onOpenFAQ,
  onOpenPrivacy,
  onOpenTerms
}) => {
  return (
    <footer className="bg-[#00204f] text-white w-full py-12 md:py-16 mt-auto">
      <div className="max-w-[1280px] mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10 md:gap-12">
          {/* Brand Column */}
          <div className="space-y-4">
            <h3 className="text-xl md:text-2xl font-bold tracking-tight text-white">
              {CONTACT_INFO.centerName}
            </h3>
            <p className="text-white/80 text-sm md:text-base leading-relaxed max-w-sm">
              Membimbing pelajar ke arah kecemerlangan akademik dengan modul pembelajaran berkesan dan guru berpengalaman.
            </p>
          </div>

          {/* Quick Links Column */}
          <div className="space-y-4">
            <h4 className="font-bold text-lg text-white tracking-wide">Pautan Pantas</h4>
            <ul className="space-y-2.5 text-sm">
              <li>
                <button
                  onClick={() => {
                    onSelectTab('home');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="text-white/80 hover:text-[#F37021] transition-colors inline-flex items-center gap-1.5"
                >
                  <ArrowRight className="w-3.5 h-3.5 opacity-60" />
                  <span>Laman Utama</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    onSelectTab('about');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="text-white/80 hover:text-[#F37021] transition-colors inline-flex items-center gap-1.5"
                >
                  <ArrowRight className="w-3.5 h-3.5 opacity-60" />
                  <span>Mengenai Kami</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    onSelectTab('program');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="text-white/80 hover:text-[#F37021] transition-colors inline-flex items-center gap-1.5"
                >
                  <ArrowRight className="w-3.5 h-3.5 opacity-60" />
                  <span>Program & Kurikulum</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    onSelectTab('contact');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="text-white/80 hover:text-[#F37021] transition-colors inline-flex items-center gap-1.5"
                >
                  <ArrowRight className="w-3.5 h-3.5 opacity-60" />
                  <span>Hubungi Kami</span>
                </button>
              </li>
            </ul>
          </div>

          {/* Contact Column */}
          <div className="space-y-4">
            <h4 className="font-bold text-lg text-white tracking-wide">Hubungi</h4>
            <ul className="space-y-3 text-sm text-white/85">
              <li className="flex items-start gap-2.5">
                <MapPin className="w-5 h-5 text-[#F37021] shrink-0 mt-0.5" />
                <span>{CONTACT_INFO.address}</span>
              </li>
              <li className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-[#F37021] shrink-0" />
                <a href={`tel:${CONTACT_INFO.primaryPhone.replace(/\s/g, '')}`} className="hover:text-[#F37021] transition-colors">
                  {CONTACT_INFO.phone}
                </a>
              </li>
              <li className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-[#F37021] shrink-0" />
                <a href={`mailto:${CONTACT_INFO.email}`} className="hover:text-[#F37021] transition-colors">
                  {CONTACT_INFO.email}
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Copyright */}
        <div className="mt-12 pt-6 border-t border-white/20 text-center text-xs text-white/70">
          <p>© 2024 Pusat Tuisyen Intelek Sukses. Hak Cipta Terpelihara.</p>
        </div>
      </div>
    </footer>
  );
};
