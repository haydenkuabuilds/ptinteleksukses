import React from 'react';
import { PageTab } from '../types';
import { ASSETS, TUTORS } from '../data/mockData';
import { BookOpen, Award, TrendingUp, CheckCircle, ArrowRight, Users, Sparkles, GraduationCap, CheckCircle2 } from 'lucide-react';

interface FeaturesMisiProps {
  onSelectTab: (tab: PageTab) => void;
  onOpenRegister: (type?: 'regular' | 'trial' | 'reading_package') => void;
}

export const FeaturesMisi: React.FC<FeaturesMisiProps> = ({ onSelectTab, onOpenRegister }) => {
  const leadTutor = TUTORS[0];

  return (
    <div>
      {/* Mengenai Kami Section */}
      <section className="py-16 md:py-24 bg-[#f7f9fb]">
        <div className="max-w-[1280px] mx-auto px-4 md:px-6">
          <div className="text-center mb-12">
            <h2 className="text-2xl md:text-3xl font-bold text-[#00204f] mb-3">
              Mengenai Kami
            </h2>
            <div className="h-1 w-20 bg-[#F37021] mx-auto rounded-full"></div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8">
            {/* Feature 1 */}
            <div className="bg-white p-6 md:p-8 rounded-xl shadow-[0_8px_24px_rgba(0,32,79,0.05)] border border-[#e0e3e5] hover:-translate-y-1.5 transition-transform duration-300 flex flex-col justify-between">
              <div>
                <div className="w-14 h-14 rounded-full bg-[#d8e2ff] flex items-center justify-center text-[#00204f] mb-6 shadow-xs">
                  <span className="material-symbols-outlined fill text-2xl text-[#00204f]">school</span>
                </div>
                <h3 className="text-xl font-bold text-[#00204f] mb-3">
                  Pendidikan Berkualiti
                </h3>
                <p className="text-sm md:text-base text-[#44474f] leading-relaxed">
                  Kami menyediakan modul pembelajaran komprehensif yang sejajar dengan silibus terkini untuk memastikan pelajar sentiasa bersedia.
                </p>
              </div>
              <div className="mt-6 pt-4 border-t border-[#f2f4f6] flex items-center text-xs font-semibold text-[#00204f]">
                <span>Modul KSSR, KSSM & UASA</span>
              </div>
            </div>

            {/* Feature 2 */}
            <div className="bg-white p-6 md:p-8 rounded-xl shadow-[0_8px_24px_rgba(0,32,79,0.05)] border border-[#e0e3e5] hover:-translate-y-1.5 transition-transform duration-300 flex flex-col justify-between">
              <div>
                <div className="w-14 h-14 rounded-full bg-[#ffdad8] flex items-center justify-center text-[#b7102a] mb-6 shadow-xs">
                  <span className="material-symbols-outlined fill text-2xl text-[#b7102a]">psychology</span>
                </div>
                <h3 className="text-xl font-bold text-[#00204f] mb-3">
                  Guru Berpengalaman
                </h3>
                <p className="text-sm md:text-base text-[#44474f] leading-relaxed">
                  Barisan pendidik kami terdiri daripada tenaga pengajar yang berdedikasi dan mempunyai pengalaman luas dalam bidang masing-masing.
                </p>
              </div>
              <div className="mt-6 pt-4 border-t border-[#f2f4f6] flex items-center text-xs font-semibold text-[#b7102a]">
                <span>Tutor Bertauliah & Mesra Pelajar</span>
              </div>
            </div>

            {/* Feature 3 */}
            <div className="bg-white p-6 md:p-8 rounded-xl shadow-[0_8px_24px_rgba(0,32,79,0.05)] border border-[#e0e3e5] hover:-translate-y-1.5 transition-transform duration-300 flex flex-col justify-between">
              <div>
                <div className="w-14 h-14 rounded-full bg-[#ffdcc3] flex items-center justify-center text-[#F37021] mb-6 shadow-xs">
                  <span className="material-symbols-outlined fill text-2xl text-[#F37021]">trending_up</span>
                </div>
                <h3 className="text-xl font-bold text-[#00204f] mb-3">
                  Pemantauan Prestasi
                </h3>
                <p className="text-sm md:text-base text-[#44474f] leading-relaxed">
                  Sistem penilaian berterusan untuk memantau perkembangan pelajar dan mengenal pasti kawasan yang memerlukan penambahbaikan.
                </p>
              </div>
              <div className="mt-6 pt-4 border-t border-[#f2f4f6] flex items-center text-xs font-semibold text-[#F37021]">
                <span>Laporan Berkala Untuk Ibu Bapa</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Educator Spotlight - Cikgu Ralliya */}
      <section className="py-16 md:py-20 bg-white border-y border-[#eceef0]">
        <div className="max-w-[1280px] mx-auto px-4 md:px-6">
          <div className="bg-[#f7f9fb] border border-[#e0e3e5] rounded-3xl p-6 sm:p-10 lg:p-12 shadow-[0_12px_36px_rgba(0,32,79,0.06)]">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
              
              {/* Big Image Column */}
              <div className="lg:col-span-5 flex justify-center">
                <div className="relative w-full max-w-sm sm:max-w-md aspect-square rounded-2xl overflow-hidden shadow-xl border-4 border-white">
                  <img
                    src={ASSETS.cikguRalliya}
                    alt="Cikgu Ralliya - Principal Bahasa Melayu Specialist"
                    className="w-full h-full object-cover select-none transition-transform duration-500 hover:scale-105"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-[#00204f]/90 via-[#00204f]/50 to-transparent p-4 text-white">
                    <p className="font-bold text-lg leading-tight">Cikgu Ralliya</p>
                    <p className="text-xs text-[#ffdcc3]">Principal Specialist & Program Director</p>
                  </div>
                </div>
              </div>

              {/* Educator Details Column */}
              <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
                <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#d8e2ff]/70 text-[#00204f] text-xs font-bold">
                  <GraduationCap className="w-4 h-4 text-[#F37021]" />
                  <span>Tenaga Pengajar Utama / Lead Educator</span>
                </div>

                <div className="space-y-2">
                  <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-[#00204f] tracking-tight">
                    Cikgu Ralliya
                  </h2>
                  <p className="text-base sm:text-lg font-bold text-[#F37021]">
                    Principal Bahasa Melayu Specialist & Program Director
                  </p>
                </div>

                <p className="text-sm sm:text-base text-[#44474f] leading-relaxed">
                  {leadTutor.bio}
                </p>

                {/* Badges / Specializations */}
                <div className="flex flex-wrap gap-2 justify-center lg:justify-start">
                  {leadTutor.specialization.map((spec, index) => (
                    <span
                      key={index}
                      className="text-xs font-semibold bg-white text-[#00204f] border border-[#d8e2ff] px-3 py-1.5 rounded-lg shadow-xs flex items-center gap-1.5"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5 text-[#28A745]" />
                      {spec}
                    </span>
                  ))}
                </div>

                {/* Actions */}
                <div className="pt-2 flex flex-col sm:flex-row gap-3 justify-center lg:justify-start">
                  <button
                    onClick={() => {
                      onSelectTab('about');
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    className="bg-[#00204f] hover:bg-[#003366] text-white text-sm font-bold px-6 py-3 rounded-lg transition-all text-center flex items-center justify-center gap-2"
                  >
                    <span>Profil Pendidik & Visi Kami</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => onOpenRegister('trial')}
                    className="bg-[#F37021] hover:bg-[#d95e14] text-white text-sm font-bold px-6 py-3 rounded-lg transition-all text-center"
                  >
                    Daftar Kelas Percubaan
                  </button>
                </div>
              </div>

            </div>
          </div>
        </div>
      </section>

      {/* Misi Kami Section */}
      <section className="py-16 md:py-20 bg-[#f7f9fb]">
        <div className="max-w-4xl mx-auto px-4 md:px-6 text-center">
          <div className="inline-flex items-center justify-center p-2 bg-[#d8e2ff]/50 rounded-full mb-4">
            <Sparkles className="w-5 h-5 text-[#00204f]" />
          </div>
          <h2 className="text-2xl md:text-3xl font-bold text-[#00204f] mb-6 tracking-tight">
            Misi Kami
          </h2>
          <p className="text-base sm:text-lg md:text-xl text-[#44474f] leading-relaxed font-normal">
            Di Pusat Tuisyen Intelek Sukses, misi kami adalah untuk melahirkan generasi yang bukan sahaja cemerlang dalam akademik, tetapi juga mempunyai sahsiah diri yang tinggi. Kami percaya bahawa setiap kanak-kanak mempunyai potensi yang unik, dan tugas kami adalah untuk menyediakan bimbingan yang tepat untuk menyerlahkan potensi tersebut. Dengan menggabungkan kaedah pengajaran tradisional dan inovatif, kami berusaha untuk menjadikan pembelajaran satu pengalaman yang menyeronokkan dan bermakna.
          </p>

          {/* Core Values Pill Grid */}
          <div className="mt-10 grid grid-cols-2 sm:grid-cols-4 gap-3 max-w-2xl mx-auto">
            <div className="p-3 bg-white border border-[#e0e3e5] rounded-lg text-center shadow-xs">
              <span className="block text-xs uppercase font-bold text-[#747780] tracking-wider mb-0.5">Nilai 1</span>
              <span className="font-bold text-[#00204f] text-sm sm:text-base">Integriti</span>
            </div>
            <div className="p-3 bg-white border border-[#e0e3e5] rounded-lg text-center shadow-xs">
              <span className="block text-xs uppercase font-bold text-[#747780] tracking-wider mb-0.5">Nilai 2</span>
              <span className="font-bold text-[#00204f] text-sm sm:text-base">Dedikasi</span>
            </div>
            <div className="p-3 bg-white border border-[#e0e3e5] rounded-lg text-center shadow-xs">
              <span className="block text-xs uppercase font-bold text-[#747780] tracking-wider mb-0.5">Nilai 3</span>
              <span className="font-bold text-[#00204f] text-sm sm:text-base">Holistik</span>
            </div>
            <div className="p-3 bg-white border border-[#e0e3e5] rounded-lg text-center shadow-xs">
              <span className="block text-xs uppercase font-bold text-[#747780] tracking-wider mb-0.5">Nilai 4</span>
              <span className="font-bold text-[#00204f] text-sm sm:text-base">Inovatif</span>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
