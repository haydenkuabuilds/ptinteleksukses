import React from 'react';
import { FAQS } from '../data/mockData';
import { X, HelpCircle, Shield, FileText } from 'lucide-react';

interface InfoModalProps {
  type: 'faq' | 'privacy' | 'terms' | null;
  onClose: () => void;
}

export const InfoModal: React.FC<InfoModalProps> = ({ type, onClose }) => {
  if (!type) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#00204f]/60 backdrop-blur-xs overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl max-w-2xl w-full shadow-2xl border border-[#c4c6d0] overflow-hidden my-8">
        
        {/* Header */}
        <div className="bg-[#00204f] text-white p-5 sm:p-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            {type === 'faq' && (
              <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center text-[#ffdcc3]">
                <HelpCircle className="w-5 h-5" />
              </div>
            )}
            {type === 'privacy' && (
              <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center text-[#d8e2ff]">
                <Shield className="w-5 h-5" />
              </div>
            )}
            {type === 'terms' && (
              <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center text-[#ffdad8]">
                <FileText className="w-5 h-5" />
              </div>
            )}
            <div>
              <h2 className="text-xl font-bold text-white">
                {type === 'faq' && 'Soalan Lazim (FAQ)'}
                {type === 'privacy' && 'Dasar Privasi & Perlindungan Data'}
                {type === 'terms' && 'Terma & Syarat Pendaftaran'}
              </h2>
              <p className="text-xs text-white/80">Pusat Tuisyen Intelek Sukses</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-white/70 hover:text-white p-1 rounded-lg hover:bg-white/10 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 max-h-[65vh] overflow-y-auto space-y-4 text-sm text-[#191c1e]">
          {type === 'faq' && (
            <div className="space-y-4">
              {FAQS.map((faq, idx) => (
                <div key={idx} className="bg-[#f7f9fb] p-4 rounded-xl border border-[#e0e3e5] space-y-1.5">
                  <span className="text-[11px] font-bold text-[#F37021] uppercase tracking-wider">{faq.category}</span>
                  <h3 className="font-bold text-[#00204f] text-sm sm:text-base">{faq.question}</h3>
                  <p className="text-xs sm:text-sm text-[#44474f] leading-relaxed">{faq.answer}</p>
                </div>
              ))}
            </div>
          )}

          {type === 'privacy' && (
            <div className="space-y-3 leading-relaxed text-xs sm:text-sm text-[#44474f]">
              <p>
                Pusat Tuisyen Intelek Sukses komited dalam melindungi privasi dan data peribadi ibu bapa serta pelajar kami selaras dengan Akta Perlindungan Data Peribadi 2010 (PDPA).
              </p>
              <h4 className="font-bold text-[#00204f] text-sm pt-2">1. Pengumpulan Maklumat</h4>
              <p>
                Maklumat seperti nama pelajar, tahun persekolahan, rekod gred, nombor telefon ibu bapa, dan alamat e-mel dikumpul hanya untuk tujuan pendaftaran kelas, penjadualan, penyampaian laporan prestasi murid, dan perhubungan rasmi pusat tuisyen.
              </p>
              <h4 className="font-bold text-[#00204f] text-sm pt-2">2. Keselamatan Data</h4>
              <p>
                Segala rekod disimpan secara selamat dan tidak akan dikongsi, dijual, atau dipindahkan kepada mana-mana pihak ketiga tanpa persetujuan bertulis.
              </p>
            </div>
          )}

          {type === 'terms' && (
            <div className="space-y-3 leading-relaxed text-xs sm:text-sm text-[#44474f]">
              <h4 className="font-bold text-[#00204f] text-sm">1. Kehadiran & Penggantian Kelas</h4>
              <p>
                Pelajar dinasihatkan menghadiri kelas mengikut jadual yang telah ditetapkan. Bagi ketidakhadiran bersebab (cuti sakit / urusan sekolah), kelas gantian boleh diaturkan tertakluk kepada kekosongan sesi mingguan.
              </p>
              <h4 className="font-bold text-[#00204f] text-sm pt-2">2. Yuran Pembelajaran</h4>
              <p>
                Yuran bulanan hendaklah diselesaikan sebelum 7 hari bulan setiap bulan. Bahan rujukan dan modul cetakan adalah termasuk dalam yuran program.
              </p>
              <h4 className="font-bold text-[#00204f] text-sm pt-2">3. Disiplin & Etika</h4>
              <p>
                Pelajar diharapkan sentiasa menghormati tenaga pengajar dan rakan sekelas bagi mewujudkan persekitaran pembelajaran yang positif dan selamat untuk semua.
              </p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-[#f8fafe] border-t border-[#e0e3e5] flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-[#00204f] text-white text-xs font-bold rounded-lg hover:bg-[#1a3668] transition-colors"
          >
            Tutup
          </button>
        </div>

      </div>
    </div>
  );
};
