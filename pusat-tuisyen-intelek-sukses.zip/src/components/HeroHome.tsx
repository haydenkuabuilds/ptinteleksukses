import React from 'react';
import { ASSETS, CONTACT_INFO } from '../data/mockData';
import { PageTab } from '../types';
import { MapPin, Sparkles, GraduationCap } from 'lucide-react';

interface HeroHomeProps {
  onSelectTab: (tab: PageTab) => void;
  onOpenRegister: (type?: 'regular' | 'trial' | 'reading_package') => void;
}

export const HeroHome: React.FC<HeroHomeProps> = ({ onSelectTab }) => {
  return (
    <section className="relative bg-white py-12 md:py-16 lg:py-20 overflow-hidden border-b border-[#eceef0]">
      <div className="max-w-[1280px] mx-auto px-4 md:px-6 grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-16 items-center">
        
        {/* Left Text Column */}
        <div className="space-y-6 z-10 text-center lg:text-left">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#d8e2ff]/60 text-[#00204f] text-xs sm:text-sm font-bold">
            <MapPin className="w-3.5 h-3.5 text-[#F37021]" />
            <span>Bayu Tinggi, Klang, Selangor</span>
          </div>

          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#00204f] leading-[1.18] tracking-tight">
            Empowering Young Minds, Achieving Academic Excellence.
          </h1>

          <p className="text-base sm:text-lg text-[#44474f] leading-relaxed max-w-2xl mx-auto lg:mx-0">
            {CONTACT_INFO.taglineBm}. Program bimbingan akademik holistik khusus untuk murid <strong className="text-[#00204f]">Prasekolah (Preschool)</strong>, <strong className="text-[#00204f]">Sekolah Rendah (Primary)</strong>, dan <strong className="text-[#00204f]">Sekolah Menengah (Secondary)</strong>.
          </p>

          <div className="flex flex-wrap items-center justify-center lg:justify-start gap-2 text-xs font-semibold text-[#00204f]">
            <span className="bg-[#f0f4f9] px-3 py-1.5 rounded-md border border-[#e0e3e5] flex items-center gap-1.5">
              <GraduationCap className="w-3.5 h-3.5 text-[#F37021]" />
              Preschool, Primary & Secondary
            </span>
            <span className="bg-[#f0f4f9] px-3 py-1.5 rounded-md border border-[#e0e3e5] flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-[#F37021]" />
              Modul Silibus KPM & Cambridge
            </span>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start pt-2">
            <button
              onClick={() => {
                onSelectTab('program');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="bg-[#F37021] hover:bg-[#d95e14] text-white text-base font-bold px-8 py-3.5 rounded-lg hover:-translate-y-0.5 transition-all shadow-[0_4px_12px_rgba(243,112,33,0.25)] text-center"
            >
              Ketahui Lebih Lanjut
            </button>

            <button
              onClick={() => {
                onSelectTab('contact');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="border-2 border-[#00204f] text-[#00204f] bg-transparent hover:bg-[#00204f] hover:text-white text-base font-bold px-8 py-3.5 rounded-lg transition-all text-center"
            >
              Hubungi Kami
            </button>
          </div>
        </div>

        {/* Right Photo Column: Tutor & Student Success Photo */}
        <div className="relative z-10 flex justify-center items-center">
          <div className="relative w-full max-w-lg rounded-2xl overflow-hidden shadow-[0_16px_36px_rgba(0,32,79,0.1)] border border-[#e0e3e5] bg-white group">
            <div className="aspect-[4/3] w-full overflow-hidden bg-slate-100 relative">
              <img
                src={ASSETS.tutorSuccessPhoto}
                alt="Pusat Tuisyen Intelek Sukses"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
