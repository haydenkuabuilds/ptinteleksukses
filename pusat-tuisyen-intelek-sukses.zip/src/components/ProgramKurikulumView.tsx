import React, { useState } from 'react';
import { SUBJECTS, ASSETS } from '../data/mockData';
import { SubjectItem } from '../types';
import { 
  Globe, 
  MessageCircle, 
  Languages, 
  BookA, 
  Calculator, 
  Sigma, 
  FlaskConical, 
  Volume2, 
  Gauge, 
  GraduationCap, 
  Sparkles,
  Award
} from 'lucide-react';

interface ProgramKurikulumViewProps {
  onOpenRegister: (type?: 'regular' | 'trial' | 'reading_package') => void;
  onOpenSchedule?: () => void;
  onSelectSubject: (subject: SubjectItem) => void;
}

export const ProgramKurikulumView: React.FC<ProgramKurikulumViewProps> = ({
  onOpenRegister,
  onOpenSchedule,
  onSelectSubject,
}) => {
  const renderSubjectIcon = (iconType: SubjectItem['iconType'], accentColor: string) => {
    const iconClass = "w-8 h-8";
    switch (iconType) {
      case 'globe':
        return <Globe className={iconClass} style={{ color: '#00204f' }} />;
      case 'user-voice':
        return <MessageCircle className={iconClass} style={{ color: '#00204f' }} />;
      case 'translate':
        return <Languages className={iconClass} style={{ color: '#00204f' }} />;
      case 'az':
        return <BookA className={iconClass} style={{ color: '#00204f' }} />;
      case 'math':
        return <Calculator className={iconClass} style={{ color: '#28A745' }} />;
      case 'sigma':
        return <Sigma className={iconClass} style={{ color: '#28A745' }} />;
      case 'science':
        return <FlaskConical className={iconClass} style={{ color: '#F37021' }} />;
      case 'phonics':
        return <Volume2 className={iconClass} style={{ color: '#6F42C1' }} />;
      case 'speed-math':
        return <Gauge className={iconClass} style={{ color: '#28A745' }} />;
      default:
        return <GraduationCap className={iconClass} style={{ color: accentColor }} />;
    }
  };

  return (
    <div className="py-8 md:py-14 space-y-12 max-w-[1280px] mx-auto px-4 md:px-6">
      
      {/* Top Hero Section matching Image 3 */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
        <div className="lg:col-span-6 space-y-5">
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-[#00204f] tracking-tight leading-tight">
            Program & Kurikulum
          </h1>
          <p className="text-base sm:text-lg text-[#44474f] leading-relaxed">
            Kami menawarkan pelbagai program yang dirancang khas untuk memenuhi keperluan pembelajaran anak anda pada setiap peringkat umur.
          </p>
        </div>

        {/* Hero Photo / Graphic: Pusat Tuisyen Intelek Sukses Logo */}
        <div className="lg:col-span-6 flex justify-center lg:justify-end">
          <div className="relative w-full max-w-md aspect-square rounded-2xl overflow-hidden shadow-[0_16px_36px_rgba(0,32,79,0.1)] bg-[#f7f9fb] border border-[#e0e3e5] p-5 md:p-6 transition-transform duration-500 hover:scale-[1.02]">
            <img
              src={ASSETS.logo}
              alt="Pusat Tuisyen Intelek Sukses Logo"
              className="w-full h-full object-contain rounded-xl select-none"
              referrerPolicy="no-referrer"
            />
          </div>
        </div>
      </section>

      {/* Package Disclaimer Notice */}
      <div className="bg-[#fff8f0] border border-[#ffdcc3] rounded-xl p-4 sm:p-5 flex items-start gap-3.5 text-[#00204f]">
        <div className="w-8 h-8 rounded-lg bg-[#F37021] text-white flex items-center justify-center shrink-0 mt-0.5 font-bold text-sm">
          ℹ️
        </div>
        <div className="space-y-1">
          <h4 className="font-bold text-sm sm:text-base text-[#00204f]">
            Makluman Ketersediaan Pakej & Tawaran Promosi
          </h4>
          <p className="text-xs sm:text-sm text-[#44474f] leading-relaxed">
            Sila ambil perhatian bahawa pakej dan promosi mungkin tertakluk kepada perubahan atau telah tamat tempoh kerana laman web ini tidak dikemas kini secara berkala. Sila hubungi pihak kami melalui WhatsApp / telefon untuk mengesahkan pakej, yuran, dan jadual terkini.
          </p>
        </div>
      </div>

      {/* 2 Program Cards Row matching Image 3 */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Card 1: Program Selepas Sekolah */}
        <div className="bg-white rounded-xl p-6 sm:p-8 border border-[#e0e3e5] shadow-[0_4px_16px_rgba(0,32,79,0.05)] hover:-translate-y-1 transition-transform">
          <div className="w-14 h-14 rounded-full bg-[#d8e2ff] flex items-center justify-center text-[#00204f] mb-5">
            <GraduationCap className="w-7 h-7 text-[#00204f]" />
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-[#00204f] mb-2">
            After-School Programs (Program Selepas Sekolah)
          </h2>
          <p className="text-sm sm:text-base text-[#44474f] leading-relaxed">
            Supervised learning environments, homework guidance, and structured academic support outside regular school hours. Membantu pelajar menyelesaikan kerja rumah dan mengulang kaji pelajaran harian dengan bimbingan tutor pakar.
          </p>
        </div>

        {/* Card 2: Kelas Percubaan Percuma */}
        <div className="bg-white rounded-xl p-6 sm:p-8 border border-[#e0e3e5] shadow-[0_4px_16px_rgba(0,32,79,0.05)] hover:-translate-y-1 transition-transform">
          <div className="w-14 h-14 rounded-full bg-[#ffdcc3] flex items-center justify-center text-[#F37021] mb-5">
            <Sparkles className="w-7 h-7 text-[#F37021]" />
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-[#00204f] mb-2">
            Free Trial Classes (Kelas Percubaan Percuma)
          </h2>
          <p className="text-sm sm:text-base text-[#44474f] leading-relaxed">
            No-obligation introductory trial sessions for eligible new students to experience our teaching style. Alami sendiri kaedah pengajaran kami sebelum membuat keputusan.
          </p>
        </div>
      </section>

      {/* Pakej Membaca & Menulis Percuma Banner Card matching Image 3 */}
      <section className="bg-white rounded-xl p-6 sm:p-8 border border-[#e0e3e5] shadow-[0_6px_20px_rgba(0,32,79,0.06)]">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 md:gap-8 items-center">
          {/* Left Classroom Photo */}
          <div className="md:col-span-5 aspect-[16/10] sm:aspect-[4/3] rounded-xl overflow-hidden bg-slate-100 border border-[#e0e3e5] shadow-xs">
            <img
              src={ASSETS.classroomPhoto}
              alt="Bilik Darjah Pusat Tuisyen Intelek Sukses"
              className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
              referrerPolicy="no-referrer"
            />
          </div>

          {/* Right Content */}
          <div className="md:col-span-7 space-y-3">
            <h2 className="text-2xl sm:text-3xl font-bold text-[#00204f]">
              Free Reading & Writing Packages (Pakej Membaca & Menulis Percuma)
            </h2>
            <p className="text-sm sm:text-base text-[#44474f] leading-relaxed">
              Special early literacy modules designed to boost confidence in foundational language skills. Khas untuk murid Prasekolah dan Tahap 1 yang mendaftar bagi subjek Bahasa Melayu dan Bahasa Inggeris.
            </p>
          </div>
        </div>
      </section>

      {/* Subjek Yang Ditawarkan Section matching Image 3 */}
      <section className="space-y-8 pt-4">
        <div className="text-center">
          <h2 className="text-2xl sm:text-3xl font-bold text-[#00204f]">
            Subjek Yang Ditawarkan
          </h2>
          <div className="h-1 w-20 bg-[#F37021] mx-auto rounded-full mt-3"></div>
        </div>

        {/* 8 Subjects (4 x 2 Grid) matching Image 3 */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
          {SUBJECTS.filter((s) => s.id !== 'speedmath').map((subject) => (
            <div
              key={subject.id}
              onClick={() => onSelectSubject(subject)}
              className="bg-white rounded-xl p-6 border border-[#e0e3e5] shadow-[0_4px_12px_rgba(0,32,79,0.04)] hover:-translate-y-1 hover:shadow-md transition-all duration-200 cursor-pointer flex flex-col items-center justify-center text-center group min-h-[140px]"
            >
              <div className="mb-3 group-hover:scale-110 transition-transform duration-200">
                {renderSubjectIcon(subject.iconType, subject.accentColor)}
              </div>
              <h3 className="font-bold text-base text-[#00204f] group-hover:text-[#F37021] transition-colors">
                {subject.name}
              </h3>
            </div>
          ))}
        </div>

        {/* 9th Subject: Teknik Kiraan Cepat (Centered Below matching Image 3) */}
        <div className="flex justify-center pt-2">
          {SUBJECTS.filter((s) => s.id === 'speedmath').map((subject) => (
            <div
              key={subject.id}
              onClick={() => onSelectSubject(subject)}
              className="w-full max-w-sm sm:max-w-md bg-white rounded-xl p-6 border border-[#e0e3e5] shadow-[0_4px_12px_rgba(0,32,79,0.04)] hover:-translate-y-1 hover:shadow-md transition-all duration-200 cursor-pointer flex flex-col items-center justify-center text-center group"
            >
              <div className="mb-3 group-hover:scale-110 transition-transform duration-200">
                {renderSubjectIcon(subject.iconType, subject.accentColor)}
              </div>
              <h3 className="font-bold text-base text-[#00204f] group-hover:text-[#28A745] transition-colors">
                {subject.name}
              </h3>
            </div>
          ))}
        </div>
      </section>

    </div>
  );
};
