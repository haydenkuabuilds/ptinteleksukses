import React, { useState } from 'react';
import { SUBJECTS } from '../data/mockData';
import { X, Download, Printer, Calendar, Clock, BookOpen, CheckCircle } from 'lucide-react';

interface ScheduleModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectSubjectToRegister: (subjectName: string) => void;
}

export const ScheduleModal: React.FC<ScheduleModalProps> = ({
  isOpen,
  onClose,
  onSelectSubjectToRegister,
}) => {
  const [activeDay, setActiveDay] = useState<string>('Isnin');

  if (!isOpen) return null;

  const days = ['Isnin', 'Selasa', 'Rabu', 'Khamis', 'Jumaat', 'Sabtu', 'Ahad'];

  const scheduleData: Record<string, Array<{ time: string; subject: string; level: string; tutor: string; room: string }>> = {
    'Isnin': [
      { time: '4:00 PM - 5:30 PM', subject: 'Bahasa Malaysia', level: 'Tahun 4, 5 & 6 (UASA)', tutor: 'Guru Berpengalaman', room: 'Bilik Bestari 1' },
      { time: '5:30 PM - 7:00 PM', subject: 'Mathematics (DLP / BM)', level: 'Tahun 4, 5 & 6', tutor: 'Guru Berpengalaman', room: 'Bilik Cerdas 2' },
      { time: '8:00 PM - 9:30 PM', subject: 'Bahasa Melayu', level: 'Tingkatan 4 & 5 (SPM)', tutor: 'Guru Berpengalaman', room: 'Bilik Bestari 1' },
      { time: '8:00 PM - 9:30 PM', subject: 'Matematik Menengah', level: 'Tingkatan 1, 2 & 3', tutor: 'Guru Berpengalaman', room: 'Bilik Cerdas 2' },
    ],
    'Selasa': [
      { time: '4:00 PM - 5:30 PM', subject: 'English (CEFR)', level: 'Primary 1, 2 & 3', tutor: 'Guru Berpengalaman', room: 'Bilik Global 3' },
      { time: '5:30 PM - 7:00 PM', subject: 'Science / Sains', level: 'Tahun 4, 5 & 6', tutor: 'Guru Berpengalaman', room: 'Makmal Eksplorasi' },
      { time: '8:00 PM - 9:30 PM', subject: 'English 1119 (SPM)', level: 'Form 4 & 5', tutor: 'Guru Berpengalaman', room: 'Bilik Global 3' },
    ],
    'Rabu': [
      { time: '4:00 PM - 5:30 PM', subject: 'Bahasa Malaysia', level: 'Tahun 1, 2 & 3 (Asas)', tutor: 'Guru Berpengalaman', room: 'Bilik Bestari 1' },
      { time: '8:00 PM - 10:00 PM', subject: 'Additional Mathematics (SPM)', level: 'Tingkatan 4 & 5', tutor: 'Guru Berpengalaman', room: 'Bilik Cerdas 2' },
    ],
    'Khamis': [
      { time: '4:00 PM - 5:30 PM', subject: 'English Grammar & Writing', level: 'Primary 4, 5 & 6', tutor: 'Guru Berpengalaman', room: 'Bilik Global 3' },
      { time: '8:00 PM - 9:30 PM', subject: 'English Literature & Essay', level: 'Form 1, 2 & 3', tutor: 'Guru Berpengalaman', room: 'Bilik Global 3' },
    ],
    'Jumaat': [
      { time: '4:30 PM - 6:30 PM', subject: 'Mandarin (SJKC / SK)', level: 'Tahun 1 - 6 & Menengah', tutor: 'Guru Berpengalaman', room: 'Bilik Harmoni 4' },
      { time: '8:00 PM - 9:30 PM', subject: 'Matematik Tambahan & Moden', level: 'Tingkatan 4 & 5 SPM', tutor: 'Guru Berpengalaman', room: 'Bilik Cerdas 2' },
    ],
    'Sabtu': [
      { time: '9:00 AM - 10:30 AM', subject: 'Phonics & Early Literacy', level: 'Prasekolah & Tahun 1', tutor: 'Guru Berpengalaman', room: 'Bilik Tunas 5' },
      { time: '9:00 AM - 11:00 AM', subject: 'Sains / Biologi / Kimia', level: 'Tingkatan 4 & 5', tutor: 'Guru Berpengalaman', room: 'Makmal Eksplorasi' },
      { time: '10:00 AM - 12:00 PM', subject: 'Bahasa Tamil (SJKT & Menengah)', level: 'Tahun 1-6 & SPM', tutor: 'Guru Berpengalaman', room: 'Bilik Harmoni 4' },
      { time: '2:00 PM - 4:00 PM', subject: 'Add Maths Intensive Score', level: 'Tingkatan 5 SPM', tutor: 'Guru Berpengalaman', room: 'Bilik Cerdas 2' },
    ],
    'Ahad': [
      { time: '9:00 AM - 10:30 AM', subject: 'Program Membaca & Menulis Percuma', level: 'Tahun 1 & 2', tutor: 'Guru Berpengalaman', room: 'Bilik Tunas 5' },
      { time: '11:00 AM - 12:30 PM', subject: 'Phonics Level 2', level: 'Tahun 1, 2 & Pemulihan', tutor: 'Guru Berpengalaman', room: 'Bilik Tunas 5' },
      { time: '2:00 PM - 3:30 PM', subject: 'Teknik Kiraan Cepat (Speed Math)', level: 'Semua Murid Rendah & Menengah', tutor: 'Guru Berpengalaman', room: 'Bilik Cerdas 2' },
    ],
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#00204f]/60 backdrop-blur-xs overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl max-w-3xl w-full shadow-2xl border border-[#c4c6d0] overflow-hidden my-8">
        
        {/* Header */}
        <div className="bg-[#00204f] text-white p-5 sm:p-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center text-[#ffdcc3]">
              <Calendar className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white">Jadual Waktu Sesi 2024 / 2025</h2>
              <p className="text-xs text-white/80">Pusat Tuisyen Intelek Sukses (Kajang, Selangor)</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-semibold text-white transition-colors"
              title="Cetak Jadual"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Cetak</span>
            </button>
            <button
              onClick={onClose}
              className="text-white/70 hover:text-white p-1 rounded-lg hover:bg-white/10 transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        {/* Day Navigation Tabs */}
        <div className="bg-[#f2f4f6] px-4 pt-3 flex overflow-x-auto gap-2 border-b border-[#e0e3e5] no-scrollbar">
          {days.map((day) => (
            <button
              key={day}
              onClick={() => setActiveDay(day)}
              className={`px-4 py-2.5 rounded-t-lg text-xs md:text-sm font-bold transition-all whitespace-nowrap ${
                activeDay === day
                  ? 'bg-white text-[#00204f] border-t-2 border-[#F37021] shadow-xs'
                  : 'text-[#44474f] hover:text-[#00204f]'
              }`}
            >
              {day}
            </button>
          ))}
        </div>

        {/* Schedule List */}
        <div className="p-6 max-h-[60vh] overflow-y-auto space-y-3">
          <div className="flex items-center justify-between text-xs text-[#747780] pb-2 border-b border-[#f2f4f6]">
            <span>Hari: <strong className="text-[#00204f]">{activeDay}</strong></span>
            <span>{scheduleData[activeDay]?.length || 0} Sesi Kelas Berjadual</span>
          </div>

          {scheduleData[activeDay]?.length ? (
            scheduleData[activeDay].map((slot, index) => (
              <div
                key={index}
                className="bg-white p-4 rounded-xl border border-[#e0e3e5] shadow-xs hover:border-[#00204f] transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 rounded bg-[#ffdcc3] text-[#391a00] text-[11px] font-bold">
                      {slot.time}
                    </span>
                    <span className="text-xs font-semibold text-[#747780]">{slot.room}</span>
                  </div>
                  <h4 className="font-bold text-[#00204f] text-base">{slot.subject}</h4>
                  <p className="text-xs text-[#44474f]">Peringkat: <span className="font-medium text-[#191c1e]">{slot.level}</span> • Tenaga Pengajar: <span className="font-medium text-[#00204f]">{slot.tutor}</span></p>
                </div>

                <button
                  onClick={() => {
                    onClose();
                    onSelectSubjectToRegister(slot.subject);
                  }}
                  className="self-start sm:self-center px-3.5 py-1.5 rounded-lg bg-[#00204f] hover:bg-[#1a3668] text-white text-xs font-bold transition-colors shrink-0"
                >
                  Pilih Sesi Ini
                </button>
              </div>
            ))
          ) : (
            <div className="py-8 text-center text-[#747780] text-sm">
              Tiada kelas berjadual untuk hari ini.
            </div>
          )}
        </div>

        {/* Footer info */}
        <div className="p-4 bg-[#f8fafe] border-t border-[#e0e3e5] flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-[#44474f]">
          <p>
            *Jadual tertakluk kepada pindaan semester dan pendaftaran kelas.
          </p>
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                alert('Jadual PDF telah dimuat turun ke peranti anda (Format Cetakan Rasmi Intelek Sukses 2024).');
              }}
              className="px-4 py-2 bg-[#F37021] text-white font-bold rounded-lg hover:bg-[#d95e14] transition-colors flex items-center gap-1.5 text-xs"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Muat Turun PDF</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
