import React from 'react';
import { TUTORS, ASSETS, CONTACT_INFO } from '../data/mockData';
import { PageTab } from '../types';
import { 
  ShieldCheck, 
  Award, 
  Users, 
  BookOpen, 
  HeartHandshake, 
  Target, 
  CheckCircle2, 
  Sparkles,
  ArrowRight,
  School,
  GraduationCap,
  Sparkle
} from 'lucide-react';

interface TentangKamiViewProps {
  onSelectTab: (tab: PageTab) => void;
  onOpenRegister: (type?: 'regular' | 'trial' | 'reading_package') => void;
}

export const TentangKamiView: React.FC<TentangKamiViewProps> = ({ onSelectTab, onOpenRegister }) => {
  return (
    <div className="py-8 md:py-14 max-w-[1280px] mx-auto px-4 md:px-6 space-y-16">
      
      {/* Hero / About Banner */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
        <div className="lg:col-span-7 space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-[#ffdcc3] text-[#391a00] text-xs font-bold uppercase tracking-wider">
            Mengenai Institusi Kami
          </div>
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#00204f] tracking-tight leading-[1.15]">
            Membimbing Kecemerlangan Minda, Membina Masa Depan
          </h1>
          <p className="text-base sm:text-lg text-[#44474f] leading-relaxed">
            Pusat Tuisyen Intelek Sukses ditubuhkan dengan matlamat murni untuk menyediakan platform pembelajaran komprehensif, inklusif, dan berkualiti tinggi bagi para pelajar di kawasan Bayu Tinggi, Klang dan kawasan sekitarnya.
          </p>
          <div className="pt-2 flex flex-wrap gap-4">
            <button
              onClick={() => onSelectTab('program')}
              className="bg-[#F37021] hover:bg-[#d95e14] text-white font-bold px-7 py-3.5 rounded-lg transition-all shadow-md flex items-center gap-2"
            >
              <span>Lihat Program & Kurikulum</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              onClick={() => onSelectTab('contact')}
              className="border-2 border-[#00204f] text-[#00204f] hover:bg-[#00204f] hover:text-white font-bold px-6 py-3.5 rounded-lg transition-all"
            >
              Hubungi Kami
            </button>
          </div>
        </div>

        {/* Right Photo: Exact Classroom Photo (WhatsApp Image 2026-08-29 at 5.57.06 PM.jpeg) */}
        <div className="lg:col-span-5">
          <div className="relative rounded-2xl overflow-hidden shadow-lg border border-[#e0e3e5] bg-white group">
            <div className="aspect-[4/3] overflow-hidden">
              <img
                src={ASSETS.classroomPhoto}
                alt="Suasana Bilik Darjah Pusat Tuisyen Intelek Sukses"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="p-4 bg-[#f8fafe] border-t border-[#e0e3e5] flex items-center justify-between text-xs font-semibold text-[#00204f]">
              <span className="flex items-center gap-1.5">
                <School className="w-4 h-4 text-[#F37021]" />
                Persekitaran Bilik Darjah Kondusif
              </span>
              <span className="text-[#747780]">Klang, Selangor</span>
            </div>
          </div>
        </div>
      </section>

      {/* Visi & Misi Cards */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-6 sm:p-8 rounded-2xl border border-[#e0e3e5] shadow-sm flex flex-col justify-between">
          <div className="space-y-3">
            <div className="w-12 h-12 rounded-xl bg-[#d8e2ff] text-[#00204f] flex items-center justify-center font-bold">
              <Target className="w-6 h-6" />
            </div>
            <h2 className="text-2xl font-bold text-[#00204f]">Visi Kami</h2>
            <p className="text-sm sm:text-base text-[#44474f] leading-relaxed">
              Menjadi pusat bimbingan tuisyen pilihan utama yang menerajui kecemerlangan akademik dan pembentukan sahsiah holistik pelajar melalui kaedah pengajaran dinamik dan progresif.
            </p>
          </div>
          <div className="mt-6 pt-4 border-t border-[#f2f4f6] text-xs font-bold text-[#00204f] flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-[#28A745]" />
            <span>Pendidikan Berimpak Tinggi</span>
          </div>
        </div>

        <div className="bg-white p-6 sm:p-8 rounded-2xl border border-[#e0e3e5] shadow-sm flex flex-col justify-between">
          <div className="space-y-3">
            <div className="w-12 h-12 rounded-xl bg-[#ffdcc3] text-[#391a00] flex items-center justify-center font-bold">
              <Sparkles className="w-6 h-6 text-[#F37021]" />
            </div>
            <h2 className="text-2xl font-bold text-[#00204f]">Misi Kami</h2>
            <p className="text-sm sm:text-base text-[#44474f] leading-relaxed">
              Melahirkan modal insan berdaya saing tinggi dengan menggabungkan silibus terkini, bimbingan peribadi yang mesra murid, serta modul pengukuhan berfokus untuk setiap tahap kebolehan.
            </p>
          </div>
          <div className="mt-6 pt-4 border-t border-[#f2f4f6] text-xs font-bold text-[#00204f] flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-[#28A745]" />
            <span>Pendekatan Bimbingan Menyeluruh</span>
          </div>
        </div>
      </section>

      {/* Tenaga Pengajar / Educator Section featuring Cikgu Ralliya */}
      <section className="space-y-8">
        <div className="text-center max-w-2xl mx-auto space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#d8e2ff]/70 text-[#00204f] text-xs font-bold mx-auto">
            <GraduationCap className="w-4 h-4 text-[#F37021]" />
            <span>Pendidik Berkaliber Tinggi</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-[#00204f]">
            Tenaga Pengajar Berdedikasi
          </h2>
          <p className="text-sm sm:text-base text-[#44474f]">
            Pendidik kami berpengalaman luas dan komited membimbing murid dari asas sehingga mencapai kecemerlangan akademik.
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          {TUTORS.map((tutor) => (
            <div
              key={tutor.id}
              className="bg-white rounded-3xl p-6 sm:p-8 lg:p-10 border border-[#e0e3e5] shadow-lg flex flex-col md:flex-row gap-8 items-center"
            >
              {/* Big High-Impact Portrait */}
              <div className="w-full sm:w-80 md:w-88 lg:w-96 aspect-square rounded-2xl overflow-hidden shrink-0 border-4 border-[#f0f4f9] shadow-md relative group">
                <img
                  src={ASSETS.cikguRalliya}
                  alt={tutor.name}
                  className="w-full h-full object-cover select-none transition-transform duration-500 group-hover:scale-105"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-[#00204f]/90 via-[#00204f]/40 to-transparent p-4 text-white">
                  <p className="font-bold text-base sm:text-lg leading-tight">Cikgu Ralliya</p>
                  <p className="text-xs text-[#ffdcc3] font-medium">{tutor.role}</p>
                </div>
              </div>

              {/* Tutor Bio & Details */}
              <div className="space-y-4 text-center md:text-left flex-1">
                <div>
                  <h3 className="font-extrabold text-2xl sm:text-3xl text-[#00204f] leading-snug">
                    {tutor.name}
                  </h3>
                  <p className="text-sm sm:text-base text-[#F37021] font-bold mt-1">
                    {tutor.role}
                  </p>
                  <p className="text-xs text-[#747780] font-medium mt-0.5">
                    {tutor.education}
                  </p>
                </div>

                <div className="h-0.5 w-16 bg-[#F37021] mx-auto md:mx-0 rounded-full"></div>

                <p className="text-sm sm:text-base text-[#44474f] leading-relaxed">
                  {tutor.bio}
                </p>

                <div className="space-y-2 pt-2">
                  <p className="text-xs uppercase font-bold text-[#00204f] tracking-wider">
                    Kepakaran Utama (Specialization)
                  </p>
                  <div className="flex flex-wrap gap-2 justify-center md:justify-start">
                    {tutor.specialization.map((spec, i) => (
                      <span
                        key={i}
                        className="text-xs bg-[#f0f4f9] border border-[#d8e2ff] text-[#00204f] px-3 py-1.5 rounded-lg font-semibold flex items-center gap-1.5 shadow-2xs"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5 text-[#28A745]" />
                        {spec}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="pt-4 flex flex-col sm:flex-row gap-3 justify-center md:justify-start">
                  <button
                    onClick={() => onOpenRegister('trial')}
                    className="bg-[#F37021] hover:bg-[#d95e14] text-white text-sm font-bold px-6 py-2.5 rounded-lg transition-all shadow-sm"
                  >
                    Daftar Kelas Bersama Cikgu Ralliya
                  </button>
                  <button
                    onClick={() => onSelectTab('contact')}
                    className="border border-[#00204f] text-[#00204f] hover:bg-[#00204f] hover:text-white text-sm font-bold px-6 py-2.5 rounded-lg transition-all"
                  >
                    Hubungi Pusat
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Kemudahan Pusat Tuisyen */}
      <section className="bg-white rounded-2xl p-6 sm:p-10 border border-[#e0e3e5] shadow-sm space-y-8">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <h2 className="text-2xl sm:text-3xl font-extrabold text-[#00204f]">
            Kemudahan & Fasiliti Pembelajaran
          </h2>
          <p className="text-sm text-[#44474f]">
            Direka khas untuk keselesaan dan fokus optimum setiap pelajar
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="p-5 bg-[#f8fafe] rounded-xl border border-[#d8e2ff]/60 space-y-2 text-center">
            <div className="w-10 h-10 rounded-lg bg-[#00204f] text-white flex items-center justify-center mx-auto text-lg font-bold">
              ❄️
            </div>
            <h3 className="font-bold text-sm text-[#00204f]">Bilik Berhawa Dingin</h3>
            <p className="text-xs text-[#44474f]">Suasana sejuk, tenang, dan kondusif untuk daya tumpuan maksimum.</p>
          </div>

          <div className="p-5 bg-[#f8fafe] rounded-xl border border-[#d8e2ff]/60 space-y-2 text-center">
            <div className="w-10 h-10 rounded-lg bg-[#00204f] text-white flex items-center justify-center mx-auto text-lg font-bold">
              📹
            </div>
            <h3 className="font-bold text-sm text-[#00204f]">Keselamatan CCTV 24 Jam</h3>
            <p className="text-xs text-[#44474f]">Pemantauan keselamatan berterusan di kawasan kelas dan laluan.</p>
          </div>

          <div className="p-5 bg-[#f8fafe] rounded-xl border border-[#d8e2ff]/60 space-y-2 text-center">
            <div className="w-10 h-10 rounded-lg bg-[#00204f] text-white flex items-center justify-center mx-auto text-lg font-bold">
              📚
            </div>
            <h3 className="font-bold text-sm text-[#00204f]">Bahan Rujukan & Modul Khas</h3>
            <p className="text-xs text-[#44474f]">Buku latihan topikal, nota ringkas, dan soalan latih tubi percuma.</p>
          </div>

          <div className="p-5 bg-[#f8fafe] rounded-xl border border-[#d8e2ff]/60 space-y-2 text-center">
            <div className="w-10 h-10 rounded-lg bg-[#00204f] text-white flex items-center justify-center mx-auto text-lg font-bold">
              🛋️
            </div>
            <h3 className="font-bold text-sm text-[#00204f]">Ruang Menunggu Ibu Bapa</h3>
            <p className="text-xs text-[#44474f]">Kawasan menunggu yang selesa dengan kemudahan WiFi dan parkir selamat.</p>
          </div>
        </div>
      </section>

    </div>
  );
};
