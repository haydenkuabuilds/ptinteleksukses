import React from 'react';
import { SubjectItem } from '../types';
import { X, BookOpen, Calendar, UserCheck, CheckCircle2, ArrowRight } from 'lucide-react';

interface SubjectDetailModalProps {
  subject: SubjectItem | null;
  onClose: () => void;
  onRegisterSubject: (subjectName: string) => void;
}

export const SubjectDetailModal: React.FC<SubjectDetailModalProps> = ({
  subject,
  onClose,
  onRegisterSubject,
}) => {
  if (!subject) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#00204f]/60 backdrop-blur-xs overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl max-w-lg w-full shadow-2xl border border-[#c4c6d0] overflow-hidden my-8">
        
        {/* Header */}
        <div className="bg-[#00204f] text-white p-6 relative">
          <button
            onClick={onClose}
            className="absolute top-5 right-5 text-white/70 hover:text-white p-1 rounded-lg hover:bg-white/10 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
          
          <span className="inline-block px-2.5 py-0.5 rounded bg-[#ffdcc3] text-[#391a00] text-[11px] font-bold uppercase tracking-wider mb-2">
            Kategori: {subject.category}
          </span>
          <h2 className="text-2xl font-bold tracking-tight text-white">{subject.name}</h2>
          <p className="text-xs text-white/80 mt-1">Silibus Bertauliah KPM (KSSR / KSSM / UASA / SPM)</p>
        </div>

        {/* Body */}
        <div className="p-6 space-y-5">
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-[#747780] mb-1.5">Penerangan Modul</h3>
            <p className="text-sm text-[#191c1e] leading-relaxed">
              {subject.description}
            </p>
          </div>

          {/* Level Badges */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-[#747780] mb-2">Peringkat Ditawarkan</h3>
            <div className="flex flex-wrap gap-1.5">
              {subject.levels.map((lvl, index) => (
                <span key={index} className="px-2.5 py-1 rounded bg-[#d8e2ff]/60 text-[#00204f] text-xs font-bold border border-[#d8e2ff]">
                  {lvl}
                </span>
              ))}
            </div>
          </div>

          {/* Key Features */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-[#747780] mb-2">Fokus Pembelajaran</h3>
            <ul className="space-y-1.5 text-xs text-[#44474f]">
              {subject.features.map((feat, index) => (
                <li key={index} className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-[#28A745] shrink-0 mt-0.5" />
                  <span>{feat}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Tutor & Registration Guidance Box */}
          <div className="bg-[#f7f9fb] p-4 rounded-xl border border-[#e0e3e5] space-y-2 text-xs">
            <div className="flex items-center gap-2 text-[#00204f]">
              <UserCheck className="w-4 h-4 text-[#F37021]" />
              <span><strong>Bimbingan:</strong> {subject.tutorName}</span>
            </div>
            <div className="flex items-start gap-2 text-[#44474f] pt-1">
              <Calendar className="w-4 h-4 text-[#F37021] shrink-0 mt-0.5" />
              <span><strong>Jadual & Sesi:</strong> Jadual kelas disusun mengikut kumpulan murid dan ketersediaan slot. Sila hubungi kami melalui WhatsApp untuk waktu sesi terkini.</span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-[#f8fafe] border-t border-[#e0e3e5] flex items-center justify-between">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-lg text-xs font-semibold text-[#44474f] hover:bg-[#e0e3e5]"
          >
            Tutup
          </button>
          <button
            onClick={() => {
              onClose();
              onRegisterSubject(subject.name);
            }}
            className="px-5 py-2.5 bg-[#00204f] hover:bg-[#1a3668] text-white text-xs font-bold rounded-lg transition-all flex items-center gap-1.5 shadow"
          >
            <span>Daftar Subjek Ini</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

      </div>
    </div>
  );
};
