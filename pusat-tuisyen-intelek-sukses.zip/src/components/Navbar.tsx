import React, { useState } from 'react';
import { PageTab } from '../types';
import { Menu, X } from 'lucide-react';

interface NavbarProps {
  currentTab: PageTab;
  onSelectTab: (tab: PageTab) => void;
  onOpenRegister: (type?: 'regular' | 'trial' | 'reading_package') => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentTab, onSelectTab, onOpenRegister }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems: { label: string; tab: PageTab }[] = [
    { label: 'Laman Utama', tab: 'home' },
    { label: 'Mengenai Kami', tab: 'about' },
    { label: 'Program & Kurikulum', tab: 'program' },
    { label: 'Hubungi Kami', tab: 'contact' },
  ];

  const handleNavClick = (tab: PageTab) => {
    onSelectTab(tab);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className="bg-white fixed top-0 w-full z-50 shadow-sm border-b border-[#e0e3e5] transition-all">
      <div className="max-w-[1280px] mx-auto px-4 md:px-6 flex justify-between items-center h-20">
        {/* Brand / Logo */}
        <div 
          onClick={() => handleNavClick('home')}
          className="text-xl md:text-2xl font-bold text-[#00204f] cursor-pointer tracking-tight flex items-center gap-2 select-none hover:opacity-90 transition-opacity"
        >
          <span>Pusat Tuisyen Intelek Sukses</span>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden lg:flex items-center space-x-8 text-[15px] font-semibold">
          {navItems.map((item) => {
            const isActive = currentTab === item.tab || (item.tab === 'program' && currentTab === 'kurikulum');

            return (
              <button
                key={item.tab}
                onClick={() => handleNavClick(item.tab)}
                className={`py-1 transition-colors duration-200 ${
                  isActive
                    ? 'text-[#F37021] font-bold'
                    : 'text-[#44474f] hover:text-[#00204f]'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </nav>

        {/* Mobile menu hamburger */}
        <div className="flex lg:hidden items-center">
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 rounded-lg text-[#00204f] hover:bg-[#f2f4f6] focus:outline-none"
            aria-label="Menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-white border-t border-[#e0e3e5] px-4 py-4 space-y-2 shadow-lg animate-in slide-in-from-top duration-200">
          {navItems.map((item) => {
            const isActive = currentTab === item.tab || (item.tab === 'program' && currentTab === 'kurikulum');
            return (
              <button
                key={item.tab}
                onClick={() => handleNavClick(item.tab)}
                className={`w-full text-left px-3 py-2.5 rounded-lg text-base font-semibold transition-colors flex items-center justify-between ${
                  isActive
                    ? 'bg-[#ffdcc3]/40 text-[#F37021]'
                    : 'text-[#191c1e] hover:bg-[#f2f4f6]'
                }`}
              >
                <span>{item.label}</span>
                {isActive && <span className="w-2 h-2 rounded-full bg-[#F37021]"></span>}
              </button>
            );
          })}
        </div>
      )}
    </header>
  );
};
