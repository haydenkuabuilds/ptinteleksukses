import React, { useState, useEffect } from 'react';
import { RegistrationFormData, SubjectItem } from '../types';
import { SUBJECTS } from '../data/mockData';
import { X, CheckCircle2, Send, Sparkles, AlertCircle, Phone, ArrowRight } from 'lucide-react';

interface RegistrationModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialType?: 'regular' | 'trial' | 'reading_package';
  onSuccess: (msg: string) => void;
}

export const RegistrationModal: React.FC<RegistrationModalProps> = ({
  isOpen,
  onClose,
  initialType = 'regular',
  onSuccess,
}) => {
  const [formData, setFormData] = useState<RegistrationFormData>({
    studentName: '',
    schoolYear: 'Tahun 3',
    schoolName: '',
    selectedSubjects: ['bm', 'math'],
    parentName: '',
    parentPhone: '',
    parentEmail: '',
    programType: initialType,
    notes: '',
  });

  const [step, setStep] = useState<1 | 2>(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isConfirmed, setIsConfirmed] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setFormData((prev) => ({
        ...prev,
        programType: initialType,
      }));
      setStep(1);
      setIsConfirmed(false);
    }
  }, [isOpen, initialType]);

  if (!isOpen) return null;

  const handleSubjectToggle = (subjectId: string) => {
    setFormData((prev) => {
      const exists = prev.selectedSubjects.includes(subjectId);
      if (exists) {
        return { ...prev, selectedSubjects: prev.selectedSubjects.filter((id) => id !== subjectId) };
      } else {
        return { ...prev, selectedSubjects: [...prev.selectedSubjects, subjectId] };
      }
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.studentName.trim() || !formData.parentName.trim() || !formData.parentPhone.trim()) {
      alert('Sila lengkapkan maklumat bertanda bintang (*).');
      return;
    }

    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      setIsConfirmed(true);
      onSuccess(`Pendaftaran untuk ${formData.studentName} berjaya dihantar!`);
    }, 600);
  };

  const getProgramTitle = () => {
    if (formData.programType === 'trial') return 'Pendaftaran Kelas Percubaan Percuma (2 Sesi)';
    if (formData.programType === 'reading_package') return 'Penebusan Pakej Membaca & Menulis Percuma';
    return 'Borang Pendaftaran Pelajar Baharu Sesi 2024/2025';
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#00204f]/60 backdrop-blur-xs overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl max-w-xl w-full shadow-2xl border border-[#c4c6d0] overflow-hidden my-8 relative">
        
        {/* Header */}
        <div className="bg-[#00204f] text-white p-5 sm:p-6 flex items-start justify-between">
          <div>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded bg-white/15 text-xs font-semibold text-[#ffdcc3] mb-2">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Pusat Tuisyen Intelek Sukses</span>
            </div>
            <h2 className="text-xl font-bold tracking-tight text-white">{getProgramTitle()}</h2>
            <p className="text-xs text-white/80 mt-1">Sila isi maklumat pelajar untuk pengesahan tempat dan jadual kelas.</p>
          </div>
          <button
            onClick={onClose}
            className="text-white/70 hover:text-white p-1 rounded-lg hover:bg-white/10 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 sm:p-8">
          {isConfirmed ? (
            <div className="text-center py-6 space-y-4">
              <div className="w-16 h-16 rounded-full bg-[#d4edda] text-[#28A745] flex items-center justify-center mx-auto shadow-sm">
                <CheckCircle2 className="w-10 h-10" />
              </div>
              <h3 className="text-2xl font-bold text-[#00204f]">Pendaftaran Berjaya!</h3>
              <p className="text-sm text-[#44474f] max-w-md mx-auto leading-relaxed">
                Terima kasih, <strong>{formData.parentName}</strong>. Pendaftaran untuk <strong>{formData.studentName}</strong> ({formData.schoolYear}) telah diterima.
              </p>
              <div className="bg-[#f7f9fb] p-4 rounded-xl text-left text-xs text-[#191c1e] space-y-2 border border-[#e0e3e5] max-w-sm mx-auto">
                <p><strong>Jenis Program:</strong> {getProgramTitle()}</p>
                <p><strong>Subjek Pilihan:</strong> {formData.selectedSubjects.map(id => SUBJECTS.find(s => s.id === id)?.name).filter(Boolean).join(', ')}</p>
                <p><strong>No. Hubungan:</strong> {formData.parentPhone}</p>
                <p className="text-[#F37021] font-semibold pt-1">Pegawai kami akan menghubungi anda melalui WhatsApp untuk pengesahan jadual waktu.</p>
              </div>

              <div className="pt-4 flex flex-col sm:flex-row justify-center gap-3">
                <a
                  href={`https://wa.me/60123456789?text=Salam%20Pusat%20Tuisyen%20Intelek%20Sukses,%20saya%20telah%20mendaftar%20untuk%20${encodeURIComponent(formData.studentName)}%20(${encodeURIComponent(formData.schoolYear)}).`}
                  target="_blank"
                  rel="noreferrer"
                  className="px-5 py-3 rounded-lg bg-[#28A745] hover:bg-[#218838] text-white text-xs font-bold transition-all shadow flex items-center justify-center gap-2"
                >
                  <Phone className="w-4 h-4" />
                  <span>Sahkan Segera Melalui WhatsApp</span>
                </a>
                <button
                  onClick={onClose}
                  className="px-5 py-3 rounded-lg border border-[#c4c6d0] text-xs font-bold text-[#00204f] hover:bg-[#f2f4f6]"
                >
                  Tutup
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-5">
              
              {/* Program Selector Pills */}
              <div>
                <label className="block text-xs font-bold text-[#00204f] mb-1.5 uppercase tracking-wider">
                  Pilihan Pakej / Program
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'regular', label: 'Program Penuh' },
                    { id: 'trial', label: 'Kelas Percubaan (Percuma)' },
                    { id: 'reading_package', label: 'Pakej Literasi' },
                  ].map((p) => (
                    <button
                      key={p.id}
                      type="button"
                      onClick={() => setFormData({ ...formData, programType: p.id as any })}
                      className={`py-2 px-2 rounded-lg text-xs font-bold text-center border transition-all ${
                        formData.programType === p.id
                          ? 'bg-[#00204f] text-white border-[#00204f] shadow-xs'
                          : 'bg-white text-[#44474f] border-[#c4c6d0] hover:bg-[#f2f4f6]'
                      }`}
                    >
                      {p.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Step 1: Student Details */}
              <div className="space-y-4 pt-2 border-t border-[#eceef0]">
                <h4 className="text-xs font-bold uppercase tracking-wider text-[#F37021]">1. Maklumat Pelajar</h4>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-[#00204f] mb-1">
                      Nama Penuh Pelajar <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.studentName}
                      onChange={(e) => setFormData({ ...formData, studentName: e.target.value })}
                      placeholder="cth. Muhammad Adam / Tan Wei Jun"
                      className="w-full rounded-lg bg-white border border-[#c4c6d0] px-3.5 py-2 text-sm text-[#191c1e] focus:outline-none focus:border-[#00204f] focus:ring-1 focus:ring-[#00204f]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-[#00204f] mb-1">
                      Tahun / Tingkatan <span className="text-red-500">*</span>
                    </label>
                    <select
                      value={formData.schoolYear}
                      onChange={(e) => setFormData({ ...formData, schoolYear: e.target.value })}
                      className="w-full rounded-lg bg-white border border-[#c4c6d0] px-3.5 py-2 text-sm text-[#191c1e] focus:outline-none focus:border-[#00204f] focus:ring-1 focus:ring-[#00204f]"
                    >
                      <option value="Prasekolah / Tadika">Prasekolah / Tadika (4-6 Tahun)</option>
                      <option value="Tahun 1">Tahun 1 (SK / SJKC / SJKT)</option>
                      <option value="Tahun 2">Tahun 2 (SK / SJKC / SJKT)</option>
                      <option value="Tahun 3">Tahun 3 (SK / SJKC / SJKT)</option>
                      <option value="Tahun 4">Tahun 4 (UASA)</option>
                      <option value="Tahun 5">Tahun 5 (UASA)</option>
                      <option value="Tahun 6">Tahun 6 (UASA)</option>
                      <option value="Tingkatan 1">Tingkatan 1 (Menengah)</option>
                      <option value="Tingkatan 2">Tingkatan 2 (Menengah)</option>
                      <option value="Tingkatan 3">Tingkatan 3 (UASA)</option>
                      <option value="Tingkatan 4">Tingkatan 4 (SPM)</option>
                      <option value="Tingkatan 5">Tingkatan 5 (SPM)</option>
                    </select>
                  </div>
                </div>

                {/* Subjek Pilihan checkboxes */}
                <div>
                  <label className="block text-xs font-bold text-[#00204f] mb-1.5">
                    Pilih Subjek Yang Ingin Diikuti:
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {SUBJECTS.map((sub) => {
                      const isSelected = formData.selectedSubjects.includes(sub.id);
                      return (
                        <button
                          key={sub.id}
                          type="button"
                          onClick={() => handleSubjectToggle(sub.id)}
                          className={`p-2 rounded-lg text-xs font-semibold text-left border flex items-center justify-between transition-colors ${
                            isSelected
                              ? 'bg-[#d8e2ff] text-[#00204f] border-[#00204f]'
                              : 'bg-white text-[#44474f] border-[#e0e3e5] hover:bg-[#f7f9fb]'
                          }`}
                        >
                          <span className="truncate">{sub.name}</span>
                          <span className={`w-3.5 h-3.5 rounded-full flex items-center justify-center text-[10px] ${isSelected ? 'bg-[#00204f] text-white' : 'border border-[#747780]'}`}>
                            {isSelected && '✓'}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Step 2: Parent / Guardian Info */}
              <div className="space-y-4 pt-3 border-t border-[#eceef0]">
                <h4 className="text-xs font-bold uppercase tracking-wider text-[#F37021]">2. Maklumat Ibu Bapa / Penjaga</h4>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-[#00204f] mb-1">
                      Nama Ibu Bapa / Penjaga <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.parentName}
                      onChange={(e) => setFormData({ ...formData, parentName: e.target.value })}
                      placeholder="Nama penuh anda"
                      className="w-full rounded-lg bg-white border border-[#c4c6d0] px-3.5 py-2 text-sm text-[#191c1e] focus:outline-none focus:border-[#00204f] focus:ring-1 focus:ring-[#00204f]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-[#00204f] mb-1">
                      No. Telefon (WhatsApp) <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="tel"
                      required
                      value={formData.parentPhone}
                      onChange={(e) => setFormData({ ...formData, parentPhone: e.target.value })}
                      placeholder="cth. 012-345 6789"
                      className="w-full rounded-lg bg-white border border-[#c4c6d0] px-3.5 py-2 text-sm text-[#191c1e] focus:outline-none focus:border-[#00204f] focus:ring-1 focus:ring-[#00204f]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#00204f] mb-1">
                    Alamat E-mel (Pilihan)
                  </label>
                  <input
                    type="email"
                    value={formData.parentEmail}
                    onChange={(e) => setFormData({ ...formData, parentEmail: e.target.value })}
                    placeholder="emel@contoh.com"
                    className="w-full rounded-lg bg-white border border-[#c4c6d0] px-3.5 py-2 text-sm text-[#191c1e] focus:outline-none focus:border-[#00204f] focus:ring-1 focus:ring-[#00204f]"
                  />
                </div>
              </div>

              {/* Package Disclaimer */}
              <div className="bg-[#fff8f0] border border-[#ffdcc3] p-3 rounded-lg text-xs text-[#44474f] leading-relaxed">
                <span className="font-bold text-[#F37021]">Makluman:</span> Pakej dan promosi mungkin tertakluk kepada perubahan / tamat tempoh kerana laman web tidak sentiasa dikemas kini. Pengesahan yuran & jadual terkini akan dimaklumkan melalui WhatsApp/telefon.
              </div>

              {/* Submit Buttons */}
              <div className="pt-4 border-t border-[#eceef0] flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-5 py-2.5 rounded-lg border border-[#c4c6d0] text-xs font-bold text-[#44474f] hover:bg-[#f2f4f6]"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-6 py-2.5 rounded-lg bg-[#00204f] hover:bg-[#1a3668] text-white text-xs sm:text-sm font-bold shadow-md hover:-translate-y-0.5 transition-all flex items-center gap-2"
                >
                  {isSubmitting ? (
                    <span>Sedang Memproses...</span>
                  ) : (
                    <>
                      <span>Hantar Pendaftaran</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </div>
            </form>
          )}
        </div>

      </div>
    </div>
  );
};
