export type PageTab = 'home' | 'about' | 'program' | 'kurikulum' | 'contact';

export interface SubjectItem {
  id: string;
  name: string;
  category: 'Bahasa' | 'STEM' | 'Pengkhususan';
  iconType: 'globe' | 'user-voice' | 'translate' | 'az' | 'math' | 'sigma' | 'science' | 'phonics' | 'speed-math';
  accentColor: string;
  description: string;
  levels: string[];
  features: string[];
  scheduleDay: string;
  scheduleTime: string;
  tutorName: string;
}

export interface ProgramItem {
  id: string;
  title: string;
  badge?: string;
  description: string;
  bulletPoints: string[];
  targetAudience: string;
  feeInfo?: string;
}

export interface TutorProfile {
  id: string;
  name: string;
  role: string;
  experience: string;
  specialization: string[];
  education: string;
  bio: string;
}

export interface ContactFormData {
  fullName: string;
  phone: string;
  email: string;
  subject: string;
  message: string;
}

export interface RegistrationFormData {
  studentName: string;
  schoolYear: string;
  schoolName: string;
  selectedSubjects: string[];
  parentName: string;
  parentPhone: string;
  parentEmail: string;
  programType: 'regular' | 'trial' | 'reading_package';
  notes?: string;
}

export interface FAQItem {
  question: string;
  answer: string;
  category: string;
}
