import React, { useState } from 'react';
import { PageTab, SubjectItem } from './types';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { HeroHome } from './components/HeroHome';
import { FeaturesMisi } from './components/FeaturesMisi';
import { ProgramKurikulumView } from './components/ProgramKurikulumView';
import { TentangKamiView } from './components/TentangKamiView';
import { HubungiView } from './components/HubungiView';
import { RegistrationModal } from './components/RegistrationModal';
import { SubjectDetailModal } from './components/SubjectDetailModal';
import { InfoModal } from './components/InfoModal';
import { Toast } from './components/Toast';
import { MessageSquare } from 'lucide-react';

export default function App() {
  const [currentTab, setCurrentTab] = useState<PageTab>('home');
  
  // Modals state
  const [isRegisterOpen, setIsRegisterOpen] = useState(false);
  const [registerType, setRegisterType] = useState<'regular' | 'trial' | 'reading_package'>('regular');
  const [selectedSubject, setSelectedSubject] = useState<SubjectItem | null>(null);
  const [infoModalType, setInfoModalType] = useState<'faq' | 'privacy' | 'terms' | null>(null);

  // Toast state
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const handleOpenRegister = (type: 'regular' | 'trial' | 'reading_package' = 'regular') => {
    setRegisterType(type);
    setIsRegisterOpen(true);
  };

  const handleSelectSubjectToRegister = (subjectName: string) => {
    handleOpenRegister('regular');
  };

  const handleSelectTab = (tab: PageTab) => {
    setCurrentTab(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#f7f9fb] text-[#191c1e] font-sans antialiased">
      
      {/* Fixed Navigation Bar */}
      <Navbar
        currentTab={currentTab}
        onSelectTab={handleSelectTab}
        onOpenRegister={handleOpenRegister}
      />

      {/* Main Content Area (padded top for fixed navbar h-20) */}
      <main className="flex-1 pt-20">
        {currentTab === 'home' && (
          <div className="animate-in fade-in duration-300">
            <HeroHome
              onSelectTab={handleSelectTab}
              onOpenRegister={handleOpenRegister}
            />
            <FeaturesMisi
              onSelectTab={handleSelectTab}
              onOpenRegister={handleOpenRegister}
            />
          </div>
        )}

        {currentTab === 'about' && (
          <div className="animate-in fade-in duration-300">
            <TentangKamiView
              onSelectTab={handleSelectTab}
              onOpenRegister={handleOpenRegister}
            />
          </div>
        )}

        {(currentTab === 'program' || currentTab === 'kurikulum') && (
          <div className="animate-in fade-in duration-300">
            <ProgramKurikulumView
              onOpenRegister={handleOpenRegister}
              onSelectSubject={(subj) => setSelectedSubject(subj)}
            />
          </div>
        )}

        {currentTab === 'contact' && (
          <div className="animate-in fade-in duration-300">
            <HubungiView
              onSuccessToast={(msg) => setToastMessage(msg)}
            />
          </div>
        )}
      </main>

      {/* Footer */}
      <Footer
        onSelectTab={handleSelectTab}
        onOpenFAQ={() => setInfoModalType('faq')}
        onOpenPrivacy={() => setInfoModalType('privacy')}
        onOpenTerms={() => setInfoModalType('terms')}
      />

      {/* Floating WhatsApp Contact Button */}
      <a
        href="https://wa.me/60123456789?text=Salam%20Pusat%20Tuisyen%20Intelek%20Sukses,%20saya%20ingin%20mendapatkan%20maklumat%20mengenai%20kelas%20tuisyen."
        target="_blank"
        rel="noreferrer"
        className="fixed bottom-6 left-6 z-40 bg-[#28A745] hover:bg-[#218838] text-white p-3.5 rounded-full shadow-[0_6px_20px_rgba(40,167,69,0.35)] flex items-center gap-2 transition-all hover:scale-105 active:scale-95 group"
        title="Hubungi Kami Melalui WhatsApp"
      >
        <MessageSquare className="w-5 h-5" />
        <span className="max-w-0 overflow-hidden whitespace-nowrap group-hover:max-w-xs transition-all duration-300 text-xs font-bold pl-0 group-hover:pl-1">
          WhatsApp Bantuan
        </span>
      </a>

      {/* Modals */}
      <RegistrationModal
        isOpen={isRegisterOpen}
        onClose={() => setIsRegisterOpen(false)}
        initialType={registerType}
        onSuccess={(msg) => setToastMessage(msg)}
      />

      <SubjectDetailModal
        subject={selectedSubject}
        onClose={() => setSelectedSubject(null)}
        onRegisterSubject={handleSelectSubjectToRegister}
      />

      <InfoModal
        type={infoModalType}
        onClose={() => setInfoModalType(null)}
      />

      {/* Global Toast */}
      <Toast
        message={toastMessage}
        onClose={() => setToastMessage(null)}
      />

    </div>
  );
}
